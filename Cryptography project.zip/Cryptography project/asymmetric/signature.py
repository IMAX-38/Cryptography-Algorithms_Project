import os
import hashlib
import math
from Crypto.PublicKey import DSA, ECC
from Crypto.Signature import DSS
from Crypto.Hash import SHA256

from primes import generate_safe_prime, find_primitive_root
from math_utils import mod_inverse

class ECDSASignature:
    def __init__(self, curve="P-256"):
        self.key = ECC.generate(curve=curve)
        self.public_key = self.key.public_key()
        
    def sign(self, msg: str | bytes) -> bytes:
        data = msg.encode() if isinstance(msg, str) else msg
        h = SHA256.new(data)
        signer = DSS.new(self.key, 'fips-186-3')
        return signer.sign(h)
        
    @staticmethod
    def verify(msg: str | bytes, signature: bytes, public_key) -> bool:
        data = msg.encode() if isinstance(msg, str) else msg
        h = SHA256.new(data)
        verifier = DSS.new(public_key, 'fips-186-3')
        try:
            verifier.verify(h, signature)
            return True
        except ValueError:
            return False

class DSASignature:
    def __init__(self, bits=1024):
        self.key = DSA.generate(bits)
        self.public_key = self.key.publickey()
        
    def sign(self, msg: str | bytes) -> bytes:
        data = msg.encode() if isinstance(msg, str) else msg
        h = SHA256.new(data)
        signer = DSS.new(self.key, 'fips-186-3')
        return signer.sign(h)
        
    @staticmethod
    def verify(msg: str | bytes, signature: bytes, public_key) -> bool:
        data = msg.encode() if isinstance(msg, str) else msg
        h = SHA256.new(data)
        verifier = DSS.new(public_key, 'fips-186-3')
        try:
            verifier.verify(h, signature)
            return True
        except ValueError:
            return False

class ElGamalSignature:
    """
    Textbook ElGamal Signature.
    (Note: In practice, DSA is preferred over textbook ElGamal signature).
    """
    def __init__(self, bits=512):
        self.p = generate_safe_prime(bits)
        self.g = find_primitive_root(self.p)
        self.x = int.from_bytes(os.urandom(bits // 8), 'big') % (self.p - 2) + 2
        self.y = pow(self.g, self.x, self.p)
        
    def sign(self, msg: str | bytes) -> tuple[int, int]:
        data = msg.encode() if isinstance(msg, str) else msg
        h = int(hashlib.sha256(data).hexdigest(), 16)
        
        while True:
            k = int.from_bytes(os.urandom((self.p.bit_length() + 7) // 8), 'big') % (self.p - 2) + 1
            if math.gcd(k, self.p - 1) == 1:
                break
                
        r = pow(self.g, k, self.p)
        k_inv = mod_inverse(k, self.p - 1)
        s = (k_inv * (h - self.x * r)) % (self.p - 1)
        return r, s
        
    def verify(self, msg: str | bytes, signature: tuple[int, int]) -> bool:
        r, s = signature
        if not (0 < r < self.p and 0 < s < self.p - 1):
            return False
        data = msg.encode() if isinstance(msg, str) else msg
        h = int(hashlib.sha256(data).hexdigest(), 16)
        
        left = pow(self.g, h, self.p)
        right = (pow(self.y, r, self.p) * pow(r, s, self.p)) % self.p
        return left == right
