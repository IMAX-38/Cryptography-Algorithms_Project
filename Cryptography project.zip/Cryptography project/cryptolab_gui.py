"""
cryptolab_gui.py
================================================================================
CryptoLab — Complete Cryptographic Suite
Design: Matrix Terminal (Consolas monospace, deep-black + bright-green palette)

Sections:
  1. Dashboard          — Module overview and navigation
  2. Classical          — Caesar, Vigenère, Hill (2x2/3x3), One-Time Pad
  3. Symmetric          — RC4, DES/3DES, AES-128/192/256, AES Finalists
  4. Asymmetric         — RSA, Diffie-Hellman, ElGamal, ECC (ECDH/ECIES)
  5. Hashing            — MD5, SHA-256/512, SHA-3, HMAC, pure-Python SHA-256
  6. Signatures         — RSA-PSS, ElGamal, DSA, ECDSA (P-256)
  7. Communications     — TCP/IP, Bluetooth RFCOMM, UDP Chat, Homomorphic Vote

Launch:
  GUI : python cryptolab_gui.py
  CLI : python main.py
================================================================================
"""
import os, sys, time, hashlib, struct, secrets, threading, socket, queue
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox

_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _ROOT)
# Ensure every subpackage folder is on sys.path and has __init__.py
for _sub in ("classical", "symmetric", "asymmetric", "hashing", "protocols", "utils"):
    _sp = os.path.join(_ROOT, _sub)
    if os.path.isdir(_sp):
        if _sp not in sys.path:
            sys.path.insert(0, _sp)
        _init = os.path.join(_sp, "__init__.py")
        if not os.path.exists(_init):
            open(_init, "w").close()

# ── pycryptodome ──────────────────────────────────────────────────────────────
try:
    from Crypto.Cipher import AES, PKCS1_OAEP
    from Crypto.PublicKey import RSA
    _CRYPTO = True
except ImportError:
    _CRYPTO = False

# ── Paillier ──────────────────────────────────────────────────────────────────
_PAILLIER = False
Paillier   = None
for _p in ("protocols.homomorphic", "homomorphic"):
    try:
        import importlib as _il
        _m = _il.import_module(_p)
        Paillier  = _m.Paillier
        _PAILLIER = True
        break
    except Exception:
        pass

# ═══════════════════════════════════════════════════════════════════════════
# PALETTE & FONTS
# ═══════════════════════════════════════════════════════════════════════════
K   = "#030803"   # background (deep dark green/black)
S   = "#050a05"   # sidebar
C   = "#020502"   # card (almost pure black)
H   = "#051105"   # section header
A   = "#004400"   # accent green
B   = "#00ff00"   # bright green (main text color)
G   = "#00cc00"   # secondary bright green
D   = "#003300"   # border
T   = "#00ff00"   # primary text (Matrix green)
DIM = "#006600"   # secondary text
MUT = "#004400"   # muted text
OK  = "#00ff00"   # green success
ERR = "#ff0000"   # red error
WRN = "#aaaa00"   # amber/yellow warning
INP = "#000000"   # input background
SEL = "#002200"   # selected / highlight

FM  = ("Consolas", 10)          # monospace body
FB  = ("Consolas", 10)          # standard bold-capable
FBB = ("Consolas", 10, "bold")  # bold labels / buttons
FT  = ("Consolas", 12, "bold")  # section titles
FS  = ("Consolas",  9)          # small/secondary labels

TCP_PORT      = 19876
UDP_PORT_BASE = 19900


def now() -> str:
    return datetime.now().strftime("%H:%M:%S")


# ═══════════════════════════════════════════════════════════════════════════
# CRYPTO HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def aes_enc(data: bytes, key: bytes):
    if _CRYPTO:
        nonce = secrets.token_bytes(16)
        c     = AES.new(key, AES.MODE_GCM, nonce=nonce)
        ct, tag = c.encrypt_and_digest(data)
        return ct, nonce, tag
    ks = hashlib.sha256(key).digest()
    ct = bytes(b ^ ks[i % 32] for i, b in enumerate(data))
    return ct, b"\x00"*16, b"\x00"*16


def aes_dec(ct, key, nonce, tag):
    if _CRYPTO:
        return AES.new(key, AES.MODE_GCM, nonce=nonce).decrypt_and_verify(ct, tag)
    ks = hashlib.sha256(key).digest()
    return bytes(b ^ ks[i % 32] for i, b in enumerate(ct))


def rsa_keygen(bits=2048):
    if _CRYPTO:
        k = RSA.generate(bits)
        return k, k.publickey()
    return None, None


def rsa_enc(data, pub):
    if _CRYPTO and pub:
        return PKCS1_OAEP.new(pub).encrypt(data)
    return data


def rsa_dec(data, priv):
    if _CRYPTO and priv:
        return PKCS1_OAEP.new(priv).decrypt(data)
    return data


def _send_frame(s, data):
    s.sendall(struct.pack("!I", len(data)) + data)


def _recv_frame(s):
    def _exact(n):
        buf = b""
        while len(buf) < n:
            c = s.recv(n - len(buf))
            if not c: return b""
            buf += c
        return buf
    raw = _exact(4)
    if not raw: return b""
    return _exact(struct.unpack("!I", raw)[0])


# ═══════════════════════════════════════════════════════════════════════════
# UI HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _append(w: tk.Text, line: str, tag: str = ""):
    w.configure(state="normal")
    w.insert("end", line + "\n", tag)
    w.see("end")
    w.configure(state="disabled")


def _clear(w: tk.Text):
    w.configure(state="normal")
    w.delete("1.0", "end")
    w.configure(state="disabled")


def _log(parent, height=10, tags=None) -> tk.Text:
    w = tk.Text(parent, bg=K, fg=T, font=FM, bd=0, state="disabled",
                wrap="word", padx=8, pady=8, height=height,
                selectbackground=SEL, selectforeground=T,
                highlightbackground=D, highlightthickness=1)
    default_tags = {"ok": OK, "err": ERR, "warn": WRN, "info": G,
                    "sent": B, "recv": OK, "sys": WRN, "crypto": G,
                    "key": G, "hash": B, "sig": OK, "dim": DIM}
    if tags:
        default_tags.update(tags)
    for name, color in default_tags.items():
        w.tag_config(name, foreground=color)
    return w


def _entry(parent, var, width=None, **kw):
    e = tk.Entry(parent, textvariable=var, bg=INP, fg=T,
                 insertbackground=T, bd=0, font=FB, relief="flat",
                 highlightbackground=D, highlightthickness=1, **kw)
    if width:
        e.configure(width=width)
    return e


def _btn(parent, text, cmd, accent=A, fg=T, **kw):
    return tk.Button(parent, text=f"[ {text.upper()} ]", command=cmd,
                     bg=accent, fg=fg, font=FBB, bd=0, relief="flat",
                     padx=12, pady=6, activebackground=B,
                     activeforeground=K, cursor="hand2", **kw)


def _label(parent, text, font=FS, fg=DIM, **kw):
    return tk.Label(parent, text=text, font=font, bg=C, fg=fg, **kw)


def _card(parent, padx=0, pady=0, **kw):
    return tk.Frame(parent, bg=C, highlightbackground=D,
                    highlightthickness=2, **kw)


def _bar(parent, color=A, **kw):
    f = tk.Frame(parent, bg=color, padx=14, pady=8, **kw)
    return f


def _sep(parent):
    return tk.Frame(parent, bg=D, height=1)


def _section_hdr(parent, icon, title, subtitle):
    hdr = tk.Frame(parent, bg=H, padx=30, pady=18, highlightbackground=D, highlightthickness=1)
    hdr.pack(fill="x")
    tk.Label(hdr, text=f"root@ciphermatrix ~# ./run_module --target {title.replace(' ', '_').lower()}", font=FT, bg=H, fg=T).pack(anchor="w")
    tk.Label(hdr, text=f"desc: {subtitle}", font=FS, bg=H, fg=DIM).pack(anchor="w")
    return hdr


def _combo(parent, var, values, **kw):
    return ttk.Combobox(parent, textvariable=var, values=values,
                        state="readonly", font=FB, **kw)


# ═══════════════════════════════════════════════════════════════════════════
# MAIN APPLICATION
# ═══════════════════════════════════════════════════════════════════════════

class App(tk.Tk):
    NAV = [
        ("🏠", "Accueil",            "dash"),
        ("📜", "Classique",          "classic"),
        ("🔒", "Symétrique",         "symmetric"),
        ("🗝",  "Asymétrique",        "asymmetric"),
        ("#",  "Hachage",            "hash"),
        ("✍",  "Signatures",         "signature"),
        ("🌐", "Communications",     "comms"),
    ]

    def __init__(self):
        super().__init__()
        self.title("CryptoLab — Suite Cryptographique Complète")
        self.geometry("1300x800")
        self.minsize(1050, 680)
        self.configure(bg=K)
        self._ttk_style()
        self._build()
        self.show("dash")

    def _ttk_style(self):
        st = ttk.Style(self)
        st.theme_use("clam")
        for w in ("TCombobox",):
            st.configure(w, fieldbackground=INP, background=C,
                         foreground=T, selectbackground=A,
                         selectforeground=T, arrowcolor=DIM,
                         bordercolor=D, lightcolor=D, darkcolor=D)
            st.map(w, fieldbackground=[("readonly", INP)],
                   foreground=[("readonly", T)])

    def _build(self):
        # TOP COMMAND STRIP
        top_bar = tk.Frame(self, bg=S)
        top_bar.pack(side="top", fill="x")

        # Brand / Logo area
        brand_frame = tk.Frame(top_bar, bg=S, padx=20, pady=10)
        brand_frame.pack(side="left")
        tk.Label(brand_frame, text="🔐 CIPHER MATRIX", font=FT, bg=S, fg=B).pack(side="left")

        # Navigation Tabs
        self._nav: dict[str, tk.Button] = {}
        for icon, label, key in self.NAV:
            b = tk.Button(top_bar, text=f"{label.upper()}",
                          font=FBB, bg=S, fg=DIM,
                          activebackground=SEL, activeforeground=T,
                          bd=0, relief="flat", padx=15, pady=12,
                          cursor="hand2",
                          command=lambda k=key: self.show(k))
            b.pack(side="left", fill="y")
            self._nav[key] = b

        # BOTTOM FOOTER
        footer = tk.Frame(self, bg=S, height=30)
        footer.pack(side="bottom", fill="x")
        footer.pack_propagate(False)

        self._stlbl = tk.Label(footer, text="SYS_READY", font=FS, bg=S, fg=DIM)
        self._stlbl.pack(side="left", padx=20, pady=5)
        
        engine_txt = "[ONLINE] CRYPTO ENGINE" if _CRYPTO else "[FALLBACK] ENGINE DEGRADED"
        engine_color = OK if _CRYPTO else ERR
        tk.Label(footer, text=engine_txt, font=FBB, bg=S, fg=engine_color).pack(side="right", padx=20, pady=5)

        # CENTER WORKSPACE
        self._content = tk.Frame(self, bg=K)
        self._content.pack(side="top", fill="both", expand=True)

        pages = [
            ("dash",       Dashboard),
            ("classic",    ClassicSection),
            ("symmetric",  SymmetricSection),
            ("asymmetric", AsymmetricSection),
            ("hash",       HashSection),
            ("signature",  SignatureSection),
            ("comms",      CommsSection),
        ]
        self._frames = {}
        for key, cls in pages:
            f = cls(self._content, self)
            f.place(relx=0, rely=0, relwidth=1, relheight=1)
            self._frames[key] = f

    def show(self, key: str):
        for k, b in self._nav.items():
            b.configure(bg=SEL if k == key else S,
                        fg=T if k == key else DIM)
        for k, f in self._frames.items():
            (f.lift if k == key else f.lower)()

    def set_status(self, msg: str, color: str = DIM):
        self._stlbl.configure(text=msg, fg=color)


# ═══════════════════════════════════════════════════════════════════════════
# DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════

class Dashboard(tk.Frame):
    CARDS = [
        ("[rwx]", "classic.bin", "César, Vigenère, Hill, OTP | Fréquentielle", "classic"),
        ("[rwx]", "symmetric.bin", "RC4, DES, AES-256 | ECB, CBC, GCM", "symmetric"),
        ("[rwx]", "asymmetric.bin", "RSA, Diffie-Hellman, ElGamal, ECC", "asymmetric"),
        ("[rwx]", "hash.bin", "MD5, SHA-256, SHA-512, SHA-3 | HMAC", "hash"),
        ("[rwx]", "signature.bin", "RSA-PSS, ElGamal, DSA, ECDSA", "signature"),
        ("[rwx]", "comms.bin", "TCP/IP, Bluetooth, UDP, Paillier Vote", "comms"),
    ]

    def __init__(self, master, app: App):
        super().__init__(master, bg=K)
        self.app = app
        self._build()

    def _build(self):
        hdr = tk.Frame(self, bg=K, padx=35, pady=28)
        hdr.pack(fill="x")
        tk.Label(hdr, text="root@ciphermatrix ~# ls -la /usr/local/crypto/modules/",
                 font=FT, bg=K, fg=B).pack(anchor="w")

        if not _CRYPTO:
            bar = tk.Frame(self, bg=ERR, pady=8, padx=25)
            bar.pack(fill="x")
            tk.Label(bar,
                     text="⚠ pycryptodome missing -> running in degraded mode.",
                     font=FS, bg=ERR, fg=K).pack(anchor="w")

        area = tk.Frame(self, bg=K, padx=50, pady=20)
        area.pack(fill="both", expand=True)

        for icon, filename, desc, target in self.CARDS:
            row = tk.Frame(area, bg=K, pady=10)
            row.pack(fill="x")
            
            tk.Label(row, text=f"{icon} root root  4096 May 18 22:00", font=FM, bg=K, fg=DIM).pack(side="left")
            tk.Label(row, text=f" {filename.ljust(18)}", font=FBB, bg=K, fg=T).pack(side="left", padx=(10, 30))
            tk.Label(row, text=f"# {desc}", font=FS, bg=K, fg=DIM).pack(side="left")
            
            _btn(row, "EXECUTE", lambda t=target: self.app.show(t), accent=S, fg=T).pack(side="right")
            
            _sep(area).pack(fill="x", pady=2)


# ═══════════════════════════════════════════════════════════════════════════
# CHIFFREMENT CLASSIQUE
# ═══════════════════════════════════════════════════════════════════════════

class ClassicSection(tk.Frame):
    ALGOS = ["César", "Vigenère", "Hill 2×2", "OTP (Vernam)"]

    def __init__(self, master, app: App):
        super().__init__(master, bg=K)
        self.app = app
        self._build()

    def _build(self):
        _section_hdr(self, "📜", "Chiffrement Classique",
                     "César · Vigenère · Hill · One-Time Pad — analyse et cryptanalyse")

        # algo selector (Terminal Tab Style)
        sel_bar = tk.Frame(self, bg=K, padx=40, pady=0)
        sel_bar.pack(fill="x")
        
        tk.Label(sel_bar, text="SELECT_ALGO: ", font=FBB, bg=K, fg=DIM).pack(side="left")
        
        self._algo_var = tk.StringVar(value=self.ALGOS[0])
        for algo in self.ALGOS:
            rb = tk.Radiobutton(sel_bar, text=f" {algo} ", variable=self._algo_var,
                                value=algo, font=FBB, bg=K, fg=T,
                                selectcolor=SEL, activebackground=K,
                                activeforeground=T, cursor="hand2",
                                indicatoron=0, bd=1, relief="solid",
                                command=self._switch_algo, pady=5, padx=10)
            rb.pack(side="left", padx=2)

        self._pages: dict[str, tk.Frame] = {}
        container = tk.Frame(self, bg=K)
        container.pack(fill="both", expand=True)

        for name, cls in [("César", CesarPanel), ("Vigenère", VigenerePanel),
                           ("Hill 2×2", HillPanel), ("OTP (Vernam)", OTPPanel)]:
            p = cls(container)
            p.place(relx=0, rely=0, relwidth=1, relheight=1)
            self._pages[name] = p

        self._switch_algo()

    def _switch_algo(self):
        sel = self._algo_var.get()
        for k, b in self._nav_btns().items() if hasattr(self, "_nav_btns") else []:
            pass
        for name, frame in self._pages.items():
            (frame.lift if name == sel else frame.lower)()

    def _nav_btns(self):
        return {}


class CesarPanel(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=K)
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/classic/caesar", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Monoalphabetic substitution. C = (P + k) mod 26.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Input block
        inp_frame = tk.Frame(main, bg=K)
        inp_frame.pack(fill="x", pady=5)
        
        row1 = tk.Frame(inp_frame, bg=K); row1.pack(fill="x", pady=2)
        tk.Label(row1, text="--text", font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
        self._txt = tk.StringVar(value="Bonjour le monde")
        _entry(row1, self._txt).pack(side="left", fill="x", expand=True)

        row2 = tk.Frame(inp_frame, bg=K); row2.pack(fill="x", pady=2)
        tk.Label(row2, text="--shift_k", font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
        self._k = tk.StringVar(value="7")
        _entry(row2, self._k, width=10).pack(side="left")

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "ENCRYPT", self._encrypt, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "DECRYPT", self._decrypt, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "BRUTE_FORCE", self._brute, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "IC_ANALYSIS", self._ic, accent=SEL).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=20)
        self._log.pack(fill="both", expand=True, pady=5)

    def _run_cesar(self, action):
        try:
            from caesar import encrypt_caesar, decrypt_caesar, brute_force_caesar
            txt = self._txt.get()
            k   = int(self._k.get())
            if action == "enc":
                res = encrypt_caesar(txt, k)
                _append(self._log, f"[{now()}] Encrypted (k={k}) : {res}", "ok")
            elif action == "dec":
                res = decrypt_caesar(txt, k)
                _append(self._log, f"[{now()}] Decrypted (k={k}) : {res}", "ok")
            elif action == "brute":
                crypto = encrypt_caesar(txt, k)
                _append(self._log, f"[{now()}] Ciphertext : {crypto}", "warn")
                for ki, score, texte in brute_force_caesar(crypto, top_n=5):
                    _append(self._log, f"  k={ki:2d}  score={score:.3f}  → {texte[:50]}", "info")
            elif action == "ic":
                from caesar import full_analysis_caesar
                crypto = encrypt_caesar(txt, k)
                res = full_analysis_caesar(crypto)
                _append(self._log, f"[{now()}] IC = {res['ic']:.4f}  (French ≈ 0.074)", "key")
                _append(self._log, f"  Probable key : k = {res['key_by_frequency']}", "ok")
                _append(self._log, f"  Decrypted    : {res['decrypted_freq'][:60]}", "ok")
        except ImportError as ie:
            _append(self._log, f"⚠ caesar.py not found: {ie}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _encrypt(self): self._run_cesar("enc")
    def _decrypt(self): self._run_cesar("dec")

    def _brute(self):
        try:
            from caesar import brute_force_caesar
            crypto = self._txt.get()
            if not crypto.strip():
                _append(self._log, "⚠ Enter a ciphertext first.", "warn"); return
            _append(self._log, f"[{now()}] Brute-force attack on: {crypto}", "warn")
            
            # Get all 26 shifts
            results = brute_force_caesar(crypto, top_n=26)   
            best_k, best_score, best_text = results[0]       # The best score (first element) is our auto-detected French text

            _append(self._log, "  k   score    candidate", "info")
            _append(self._log, "  ─── ──────── ──────────────────────────────────────", "info")
            
            # Sort by key 0 to 25 to show all variations in order
            results_ordered = sorted(results, key=lambda x: x[0])
            for ki, score, texte in results_ordered:
                is_best = (ki == best_k)
                prefix  = "  ★ " if is_best else "    "
                style   = "key" if is_best else "dim"
                _append(self._log, f"{prefix}k={ki:2d}  {score:.4f}   {texte[:50]}", style)
                
            _append(self._log, "", "info")
            _append(self._log, f"  ★ Auto-detected French text (k={best_k}):", "ok")
            _append(self._log, f"    {best_text}", "ok")
        except ImportError as ie:
            _append(self._log, f"⚠ caesar.py not found: {ie}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _ic(self):
        try:
            from caesar import full_analysis_caesar
            crypto = self._txt.get()
            res = full_analysis_caesar(crypto)
            _append(self._log, f"[{now()}] IC = {res['ic']:.4f}  (French ≈ 0.074)", "key")
            _append(self._log, f"  Probable key : k = {res['key_by_frequency']}", "ok")
            _append(self._log, f"  Decrypted    : {res['decrypted_freq'][:60]}", "ok")
        except ImportError as ie:
            _append(self._log, f"⚠ caesar.py not found: {ie}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")


class VigenerePanel(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=K)
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/classic/vigenere", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Substitution polyalphabétique. C[i] = (P[i] + K[i mod|K|]) mod 26.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Input block
        inp_frame = tk.Frame(main, bg=K)
        inp_frame.pack(fill="x", pady=5)
        
        for lbl, attr, val in [("--text", "_txt", "les sciences sont belles"),
                               ("--key", "_key", "CRYPTO")]:
            row = tk.Frame(inp_frame, bg=K); row.pack(fill="x", pady=2)
            tk.Label(row, text=lbl, font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
            setattr(self, attr, tk.StringVar(value=val))
            _entry(row, getattr(self, attr)).pack(side="left", fill="x", expand=True)

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "ENCRYPT", self._enc, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "DECRYPT", self._dec, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "KASISKI_ANALYSIS", self._analyse, accent=SEL).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=20)
        self._log.pack(fill="both", expand=True, pady=5)

    def _enc(self):
        try:
            from vigenere import encrypt_vigenere
            key = self._key.get()
            if not key.strip():
                _append(self._log, "⚠ Enter a key first.", "warn"); return
            enc = encrypt_vigenere(self._txt.get(), key)
            _append(self._log, f"[{now()}] Encrypted : {enc}", "ok")
            _append(self._log, "  → Copy this ciphertext, paste it above, then click 'Kasiski + IC Analysis'.", "info")
        except ImportError as ie:
            _append(self._log, f"⚠ vigenere.py not found: {ie}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _dec(self):
        try:
            from vigenere import decrypt_vigenere
            key = self._key.get()
            if not key.strip():
                _append(self._log, "⚠ Enter a key first.", "warn"); return
            dec = decrypt_vigenere(self._txt.get(), key)
            _append(self._log, f"[{now()}] Decrypted : {dec}", "ok")
        except ImportError as ie:
            _append(self._log, f"⚠ vigenere.py not found: {ie}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _analyse(self):
        """Kasiski trigram test + IC + chi² key recovery. Text field = CIPHERTEXT."""
        try:
            from vigenere import cryptanalyze_vigenere
            from collections import Counter
            from math import gcd
            from functools import reduce
            raw    = self._txt.get().upper()
            crypto = ''.join(c for c in raw if c.isalpha())
            if len(crypto) < 40:
                _append(self._log, f"⚠ Only {len(crypto)} letters — need at least 40 for Kasiski.", "warn")
                _append(self._log, "  Step 1: type your plaintext + key → click Encrypt.", "info")
                _append(self._log, "  Step 2: copy the ciphertext into the text field.", "info")
                _append(self._log, "  Step 3: click 'Kasiski + IC Analysis'.", "info")
                return
            _append(self._log, f"[{now()}] Kasiski + IC on {len(crypto)} chars:", "warn")
            # ── Kasiski: repeated trigrams ─────────────────────────────────────
            _append(self._log, "  ── Kasiski Test (repeated trigrams) ──", "info")
            all_tri = Counter(crypto[i:i+3] for i in range(len(crypto) - 2))
            repeated = [(tri, cnt,
                         [i for i in range(len(crypto) - 2) if crypto[i:i+3] == tri])
                        for tri, cnt in all_tri.items() if cnt >= 2]
            repeated.sort(key=lambda x: -x[1])
            if not repeated:
                _append(self._log, "  No repeated trigrams found — text may be too short.", "warn")
            else:
                _append(self._log, f"  Found {len(repeated)} repeated trigram(s):", "info")
                for tri, cnt, positions in repeated[:6]:
                    diffs = [positions[j+1] - positions[j] for j in range(len(positions)-1)]
                    g = reduce(gcd, diffs) if len(diffs) > 1 else diffs[0]
                    _append(self._log, f"    '{tri}' ×{cnt}  positions={positions[:4]}  gaps={diffs}  gcd={g}", "key")
            # ── Cryptanalysis result ───────────────────────────────────────────
            _append(self._log, "  ── Cryptanalysis Result ──", "info")
            res = cryptanalyze_vigenere(crypto)
            _append(self._log, f"  Probable key length : {res['probable_length']}", "info")
            _append(self._log, f"  ★ Recovered key     : {res['probable_key']}", "key")
            _append(self._log, f"  ★ Decrypted text    : {res['decrypted_text'][:80]}", "ok")
        except ImportError as ie:
            _append(self._log, f"⚠ vigenere.py not found: {ie}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")


class HillPanel(tk.Frame):
    CLE_2x2 = [[3, 3], [2, 5]]

    def __init__(self, master):
        super().__init__(master, bg=K)
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/classic/hill", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Chiffre par blocs matriciel. C = K × P mod 26. Clé valide si gcd(det(K), 26) = 1.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Input block
        inp_frame = tk.Frame(main, bg=K)
        inp_frame.pack(fill="x", pady=5)
        
        row1 = tk.Frame(inp_frame, bg=K); row1.pack(fill="x", pady=2)
        tk.Label(row1, text="--text", font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
        self._txt = tk.StringVar(value="CRYPTOGRAPHIE")
        _entry(row1, self._txt).pack(side="left", fill="x", expand=True)

        row_size = tk.Frame(inp_frame, bg=K); row_size.pack(fill="x", pady=2)
        tk.Label(row_size, text="--size", font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
        self._size = tk.IntVar(value=2)
        tk.Radiobutton(row_size, text="2x2", variable=self._size, value=2, bg=K, fg=T, selectcolor=K, activebackground=K, activeforeground=T, command=self._update_ui).pack(side="left")
        tk.Radiobutton(row_size, text="3x3", variable=self._size, value=3, bg=K, fg=T, selectcolor=K, activebackground=K, activeforeground=T, command=self._update_ui).pack(side="left")

        # Matrix block
        self.mat_frame = tk.Frame(inp_frame, bg=K)
        self.mat_frame.pack(fill="x", pady=2)
        tk.Label(self.mat_frame, text="--matrix", font=FS, bg=K, fg=DIM, width=8, anchor="ne").pack(side="left", anchor="n", padx=5)
        
        self.grid_frame = tk.Frame(self.mat_frame, bg=K)
        self.grid_frame.pack(side="left")

        self._k = [[tk.StringVar() for _ in range(3)] for _ in range(3)]
        self.entries = []
        for r in range(3):
            row_f = tk.Frame(self.grid_frame, bg=K)
            row_f.pack(fill="x")
            row_entries = []
            for c in range(3):
                e = _entry(row_f, self._k[r][c], width=4)
                row_entries.append(e)
            self.entries.append(row_entries)

        self._update_ui()

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "ENCRYPT", self._enc, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "DECRYPT", self._dec, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "KNOWN_PLAINTEXT_ATTACK", self._attack, accent=SEL).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=15)
        self._log.pack(fill="both", expand=True, pady=5)

    def _update_ui(self):
        s = self._size.get()
        if s == 2:
            self._k[0][0].set("3"); self._k[0][1].set("3")
            self._k[1][0].set("2"); self._k[1][1].set("5")
        else:
            self._k[0][0].set("6"); self._k[0][1].set("24"); self._k[0][2].set("1")
            self._k[1][0].set("13"); self._k[1][1].set("16"); self._k[1][2].set("10")
            self._k[2][0].set("20"); self._k[2][1].set("17"); self._k[2][2].set("15")

        for r in range(3):
            for c in range(3):
                if r < s and c < s:
                    self.entries[r][c].pack(side="left", padx=2, pady=2)
                else:
                    self.entries[r][c].pack_forget()

    def _get_key(self):
        s = self._size.get()
        try:
            mat = []
            for r in range(s):
                row = []
                for c in range(s):
                    row.append(int(self._k[r][c].get()))
                mat.append(row)
            return mat
        except ValueError:
            return None

    def _enc(self):
        try:
            from hill import encrypt_hill
            key = self._get_key()
            if not key:
                _append(self._log, "⚠ Invalid key matrix. Must be integers.", "err"); return
            enc = encrypt_hill(self._txt.get(), key)
            _append(self._log, f"[{now()}] Encrypted with key {key} : {enc}", "ok")
        except ImportError as ie:
            _append(self._log, f"⚠ hill.py not found: {ie}", "err")
        except ValueError as ve:
             _append(self._log, f"⚠ Key error: {ve}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _dec(self):
        try:
            from hill import decrypt_hill
            key = self._get_key()
            if not key:
                _append(self._log, "⚠ Invalid key matrix. Must be integers.", "err"); return
            dec = decrypt_hill(self._txt.get(), key)
            _append(self._log, f"[{now()}] Decrypted with key {key} : {dec}", "ok")
        except ImportError as ie:
            _append(self._log, f"⚠ hill.py not found: {ie}", "err")
        except ValueError as ve:
             _append(self._log, f"⚠ Key error: {ve}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _attack(self):
        def _run():
            try:
                from hill import encrypt_hill, known_plaintext_attack
                import random, string
                _append(self._log, f"[{now()}] Launching known-plaintext attack…", "warn")
                key = self._get_key() or self.CLE_2x2
                s = len(key)
                for _ in range(40):
                    pairs = []
                    for __ in range(s):
                        plaintext = ''.join(random.choices(string.ascii_uppercase, k=s))
                        ciphertext = encrypt_hill(plaintext, key)
                        pairs.append((plaintext, ciphertext))
                    res = known_plaintext_attack(pairs, s)
                    if res.get("success"):
                        self.after(0, lambda r=res, p=pairs, k=key: (
                            _append(self._log, f"  Pairs      : {p}", "info"),
                            _append(self._log, f"  Real key   : {k}", "info"),
                            _append(self._log, f"  Recovered  : {r['recovered_key']}", "key"),
                            _append(self._log, "  Success ✓", "ok")
                        ))
                        return
                self.after(0, lambda: _append(self._log, "  No invertible pair found.", "err"))
            except ImportError as ie:
                self.after(0, lambda ie=ie: _append(self._log, f"⚠ hill.py not found: {ie}", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Error: {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()


class OTPPanel(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=K)
        self._key = None
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/classic/otp_vernam", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Perfect Secrecy (Shannon). C = M XOR K. Vulnerable to key reuse (Crib Dragging).", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Input block
        inp_frame = tk.Frame(main, bg=K)
        inp_frame.pack(fill="x", pady=5)
        
        for lbl, attr, val in [("--msg1", "_m1", "Le mot de passe est ALPHA"),
                               ("--msg2", "_m2", "Rendez-vous a minuit ici")]:
            row = tk.Frame(inp_frame, bg=K); row.pack(fill="x", pady=2)
            tk.Label(row, text=lbl, font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
            setattr(self, attr, tk.StringVar(value=val))
            _entry(row, getattr(self, attr)).pack(side="left", fill="x", expand=True)

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "ENCRYPT_M1", self._enc, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "DECRYPT", self._dec, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "VULN_REUSE", self._vuln, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "CRIB_DRAGGING", self._crib, accent=SEL).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=20)
        self._log.pack(fill="both", expand=True, pady=5)

    def _enc(self):
        try:
            from otp import encrypt_text
            ct, key = encrypt_text(self._m1.get())
            self._key = key
            self._ct  = ct
            _append(self._log, f"[{now()}] Key (hex)   : {key.hex()}", "key")
            _append(self._log, f"[{now()}] Ciphertext  : {ct.hex()}", "ok")
        except ImportError as ie:
            _append(self._log, f"⚠ otp.py not found: {ie}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _dec(self):
        try:
            from otp import decrypt_text
            if not self._key:
                _append(self._log, "⚠ Encrypt first.", "warn"); return
            dec = decrypt_text(self._ct, self._key)
            _append(self._log, f"[{now()}] Decrypted   : {dec}", "ok")
        except ImportError as ie:
            _append(self._log, f"⚠ otp.py not found: {ie}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _vuln(self):
        try:
            from otp import demo_key_reuse
            res = demo_key_reuse(self._m1.get(), self._m2.get())
            _append(self._log, f"[{now()}] C1 ⊕ C2 = {res['xor_c1_c2_hex'][:48]}…", "warn")
            _append(self._log, f"  M1 ⊕ M2 = {res['xor_m1_m2_hex'][:48]}…", "info")
            _append(self._log, f"  Equal    : {res['xor_equal']}  ← key cancels out !", "ok")
            self._xor = res["_xor"]
        except ImportError as ie:
            _append(self._log, f"⚠ otp.py not found: {ie}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _crib(self):
        try:
            from otp import demo_key_reuse, crib_dragging
            if not hasattr(self, "_xor"):
                self._vuln()
            _append(self._log, f"[{now()}] Attaque Crib Dragging sur M1 ⊕ M2...", "warn")
            for crib in ["Le ", "mot ", "Rendez", "minuit"]:
                hits = crib_dragging(self._xor, crib, score_threshold=1.0)
                if hits:
                    _append(self._log, f"  Mot '{crib}' deviné à la position {hits[0]['position']}", "info")
                    _append(self._log, f"  → Révèle une partie de l'autre message : '{hits[0]['fragment_m2']}'", "key")
        except ImportError as ie:
            _append(self._log, f"⚠ otp.py not found: {ie}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")


# ═══════════════════════════════════════════════════════════════════════════
# CHIFFREMENT SYMÉTRIQUE
# ═══════════════════════════════════════════════════════════════════════════

class SymmetricSection(tk.Frame):
    ALGOS = ["RC4", "DES / 3DES", "AES", "AES Finalists"]

    def __init__(self, master, app: App):
        super().__init__(master, bg=K)
        self.app = app
        self._build()

    def _build(self):
        _section_hdr(self, "🔒", "Chiffrement Symétrique",
                     "RC4 · DES / Triple-DES · AES-128/192/256 — modes ECB, CBC, CTR, GCM")

        # Sub-navigation (Terminal Tab Style)
        sel_bar = tk.Frame(self, bg=K, padx=40, pady=0)
        sel_bar.pack(fill="x")
        
        tk.Label(sel_bar, text="SELECT_ALGO: ", font=FBB, bg=K, fg=DIM).pack(side="left")
        
        self._algo_var = tk.StringVar(value=self.ALGOS[0])
        for algo in self.ALGOS:
            rb = tk.Radiobutton(sel_bar, text=f" {algo} ", variable=self._algo_var,
                                value=algo, font=FBB, bg=K, fg=T,
                                selectcolor=SEL, activebackground=K,
                                activeforeground=T, cursor="hand2",
                                indicatoron=0, bd=1, relief="solid",
                                command=self._switch, pady=5, padx=10)
            rb.pack(side="left", padx=2)

        self._pages: dict[str, tk.Frame] = {}
        cont = tk.Frame(self, bg=K)
        cont.pack(fill="both", expand=True)
        for name, cls in [("RC4", RC4Panel), ("DES / 3DES", DESPanel), ("AES", AESPanel),
                           ("AES Finalists", AESFinalistsPanel)]:
            p = cls(cont)
            p.place(relx=0, rely=0, relwidth=1, relheight=1)
            self._pages[name] = p
        self._switch()

    def _switch(self):
        sel = self._algo_var.get()
        for name, frame in self._pages.items():
            (frame.lift if name == sel else frame.lower)()


class RC4Panel(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=K)
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/symmetric/rc4", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Stream Cipher (KSA + PRGA). Deprecated (RC4 biases, WEP). Use AES-GCM.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Input block
        inp_frame = tk.Frame(main, bg=K)
        inp_frame.pack(fill="x", pady=5)
        
        for lbl, attr, val in [("--key", "_key", "SecretKey"), ("--text", "_txt", "Hello, RC4!")]:
            row = tk.Frame(inp_frame, bg=K); row.pack(fill="x", pady=2)
            tk.Label(row, text=lbl, font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
            setattr(self, attr, tk.StringVar(value=val))
            _entry(row, getattr(self, attr)).pack(side="left", fill="x", expand=True)

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "ENCRYPT_DECRYPT", self._enc, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "WEP_VULNERABILITY", self._wep_demo, accent=ERR).pack(side="left", padx=5)
        _btn(act_frame, "STATISTICAL_BIAS", self._bias_demo, accent=SEL).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=20)
        self._log.pack(fill="both", expand=True, pady=5)

    def _enc(self):
        try:
            from rc4 import encrypt_text, decrypt_text
            key = self._key.get()
            txt = self._txt.get()
            ct  = encrypt_text(txt, key)
            dec = decrypt_text(ct, key)
            _append(self._log, f"[{now()}] Key       : {key}", "key")
            _append(self._log, f"[{now()}] Encrypted : {ct.hex()}", "ok")
            _append(self._log, f"[{now()}] Decrypted : {dec}", "ok")
            _append(self._log, "⚠ RC4 is deprecated — use AES-GCM", "warn")
        except ImportError:
            # Fallback pure Python RC4
            key = self._key.get().encode()
            txt = self._txt.get().encode()
            S = list(range(256)); j = 0
            for i in range(256):
                j = (j + S[i] + key[i % len(key)]) % 256
                S[i], S[j] = S[j], S[i]
            i = j = 0; ct = []
            for byte in txt:
                i = (i + 1) % 256; j = (j + S[i]) % 256
                S[i], S[j] = S[j], S[i]
                ct.append(byte ^ S[(S[i] + S[j]) % 256])
            ct = bytes(ct)
            _append(self._log, f"[{now()}] [Pure Python RC4 fallback]", "warn")
            _append(self._log, f"[{now()}] Encrypted : {ct.hex()}", "ok")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _wep_demo(self):
        """Ex 2.1.2 — RC4 WEP weak IV correlation attack demo."""
        def _ksa_prga(key_bytes, n=3):
            S = list(range(256)); j = 0
            for i in range(256):
                j = (j + S[i] + key_bytes[i % len(key_bytes)]) % 256
                S[i], S[j] = S[j], S[i]
            i = j = 0; ks = []
            for _ in range(n):
                i = (i+1)%256; j=(j+S[i])%256; S[i],S[j]=S[j],S[i]
                ks.append(S[(S[i]+S[j])%256])
            return ks
        def _run():
            secret = b"\xAB\xCD\xEF"  # 3-byte WEP secret
            _append(self._log, f"[{now()}] WEP Weak-IV attack (Ex 2.1.2)", "warn")
            _append(self._log, f"  Secret key: {secret.hex()}  (simulated)", "key")
            _append(self._log, "  IV      | 1st keystream byte | Expected (secret[0]+3)", "info")
            votes = [0]*256
            for iv_b in range(16):
                iv = bytes([iv_b, 0xFF, 0xFF])
                full_key = iv + secret
                ks = _ksa_prga(full_key, 3)
                votes[ks[0]] += 1
                self.after(0, lambda i=iv_b, k=ks[0]: _append(
                    self._log, f"  IV=0x{i:02X} | ks[0]=0x{k:02X}", "info"))
            best = votes.index(max(votes))
            self.after(0, lambda: (
                _append(self._log, f"  Most frequent 1st byte: 0x{best:02X}", "key"),
                _append(self._log, f"  → Correlates to secret byte (WEP bias) ⚠", "err"),
                _append(self._log, "  This is why RC4 was banned in TLS 1.3.", "warn")
            ))
        threading.Thread(target=_run, daemon=True).start()

    def _bias_demo(self):
        """Ex 2.1.3 — Statistical bias of the 2nd keystream byte (Mantin-Shamir bias)."""
        def _run():
            import os
            _append(self._log, f"[{now()}] Generating 10,000 RC4 keystreams...", "warn")
            zeros = 0
            for _ in range(10000):
                key = os.urandom(16)
                S = list(range(256)); j = 0
                for i in range(256):
                    j = (j + S[i] + key[i % 16]) % 256
                    S[i], S[j] = S[j], S[i]
                i = j = 0
                # Byte 1
                i = (i + 1) % 256; j = (j + S[i]) % 256; S[i], S[j] = S[j], S[i]
                # Byte 2
                i = (i + 1) % 256; j = (j + S[i]) % 256; S[i], S[j] = S[j], S[i]
                ks2 = S[(S[i] + S[j]) % 256]
                if ks2 == 0:
                    zeros += 1
            
            expected = 10000 / 256
            self.after(0, lambda: (
                _append(self._log, f"  Expected '0x00' count (uniform): {expected:.0f}", "info"),
                _append(self._log, f"  Actual '0x00' count (RC4 bias) : {zeros}", "key"),
                _append(self._log, "  → The 2nd byte is strongly biased toward zero (approx 1/128).", "err"),
                _append(self._log, "  This breaks statistical randomness.", "err")
            ))
        threading.Thread(target=_run, daemon=True).start()


class DESPanel(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=K)
        self._params = None
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/symmetric/des_3des", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Bloc Cipher (64-bit block). DES broken (56-bit key). 3DES deprecated (NIST 2019).", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Input block
        inp_frame = tk.Frame(main, bg=K)
        inp_frame.pack(fill="x", pady=5)
        
        row1 = tk.Frame(inp_frame, bg=K); row1.pack(fill="x", pady=2)
        tk.Label(row1, text="--text", font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
        self._txt = tk.StringVar(value="Message DES exemple")
        _entry(row1, self._txt).pack(side="left", fill="x", expand=True)

        row2 = tk.Frame(inp_frame, bg=K); row2.pack(fill="x", pady=2)
        tk.Label(row2, text="--algo", font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
        self._mode = tk.StringVar(value="3DES")
        _combo(row2, self._mode, ["DES", "3DES"], width=10).pack(side="left")

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "ENCRYPT", self._enc, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "DECRYPT", self._dec, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "COMPARE_ECB_CBC_TEXT", self._compare, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "COMPARE_ECB_CBC_IMG", self._img_compare, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "BENCHMARK_3DES", self._benchmark, accent=SEL).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=20)
        self._log.pack(fill="both", expand=True, pady=5)

    def _enc(self):
        try:
            from des_cipher import encrypt_text
            self._params = encrypt_text(self._txt.get(), use_3des=(self._mode.get()=="3DES"))
            _append(self._log, f"[{now()}] Algo : {self._params['algorithm']}", "info")
            _append(self._log, f"[{now()}] Key  : {self._params['key'].hex()}", "key")
            _append(self._log, f"[{now()}] IV   : {self._params['iv'].hex()}", "key")
            _append(self._log, f"[{now()}] CT   : {self._params['ciphertext'].hex()[:48]}…", "ok")
        except ImportError:
            _append(self._log, "⚠ des_cipher.py not found (pycryptodome required).", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _dec(self):
        try:
            from des_cipher import decrypt_text
            if not self._params:
                _append(self._log, "⚠ Encrypt first.", "warn"); return
            dec = decrypt_text(self._params)
            _append(self._log, f"[{now()}] Decrypted : {dec}", "ok")
        except ImportError:
            _append(self._log, "⚠ des_cipher.py not found.", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _compare(self):
        try:
            from des_cipher import compare_ecb_cbc
            txt = ("BLOC_REPETITIF  " * 8).encode() # Exactement 128 octets
            res = compare_ecb_cbc(txt)
            _append(self._log, f"[{now()}] DES Key : {res['key']}", "key")
            _append(self._log, f"  ECB repeated blocks : {res['ecb_repeated_blocks']}", "warn")
            _append(self._log, f"  CBC repeated blocks : {res['cbc_repeated_blocks']}", "ok")
            if res['ecb_repeated_blocks'] > 0:
                _append(self._log, "  ⚠ ECB: structure visible in ciphertext!", "err")
            _append(self._log, "  ✓ CBC: chaining hides all repetition.", "ok")
        except ImportError:
            _append(self._log, "⚠ des_cipher.py not found.", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _img_compare(self):
        """Ex 2.2.2 — Faiblesse ECB visualisée sur image 64x64."""
        def _run():
            try:
                from des_cipher import ecb_image_weakness
                self.after(0, lambda: _append(self._log, f"[{now()}] Génération des images ECB/CBC (Patientez)...", "warn"))
                res = ecb_image_weakness()
                if "error" in res:
                    self.after(0, lambda: _append(self._log, f"⚠ {res['error']}", "err"))
                    return
                self.after(0, lambda: (
                    _append(self._log, f"  Image originale : {res['original_path']}", "info"),
                    _append(self._log, f"  Image DES-ECB   : {res['ecb_path']}", "warn"),
                    _append(self._log, f"  Image DES-CBC   : {res['cbc_path']}", "ok"),
                    _append(self._log, f"  Observation     : {res['observation']}", "key"),
                    _append(self._log, f"  → Vérifiez le dossier du projet pour voir les images !", "ok")
                ))
            except ImportError:
                self.after(0, lambda: _append(self._log, "⚠ des_cipher.py not found.", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Error: {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()

    def _benchmark(self):
        """Ex 2.2.3 — DES vs 3DES performance benchmark on 1 MB."""
        def _run():
            try:
                from des_cipher import benchmark_des_vs_3des
                self.after(0, lambda: _append(self._log, f"[{now()}] Benchmarking DES vs 3DES (1 MB)…", "warn"))
                r = benchmark_des_vs_3des(data_size_mb=1.0, iterations=3)
                self.after(0, lambda: (
                    _append(self._log, f"  DES  : {r['des_time_s']*1000:.1f} ms  ({r['des_throughput_mbs']:.1f} MB/s)", "ok"),
                    _append(self._log, f"  3DES : {r['tdes_time_s']*1000:.1f} ms  ({r['tdes_throughput_mbs']:.1f} MB/s)", "key"),
                    _append(self._log, f"  3DES is ×{r['slowdown_factor']:.1f} slower than DES.", "warn"),
                    _append(self._log, "  → Use AES-256 — faster and far more secure.", "ok")
                ))
            except ImportError:
                self.after(0, lambda: _append(self._log, "⚠ des_cipher.py not found.", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Error: {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()


class AESPanel(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=K)
        self._params = None
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/symmetric/aes", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Advanced Encryption Standard (Rijndael). Recommended modes: GCM (Authenticated).", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Input block
        inp_frame = tk.Frame(main, bg=K)
        inp_frame.pack(fill="x", pady=5)
        
        row1 = tk.Frame(inp_frame, bg=K); row1.pack(fill="x", pady=2)
        tk.Label(row1, text="--text", font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
        self._txt = tk.StringVar(value="Message confidentiel AES-256!")
        _entry(row1, self._txt).pack(side="left", fill="x", expand=True)

        row2 = tk.Frame(inp_frame, bg=K); row2.pack(fill="x", pady=2)
        tk.Label(row2, text="--mode", font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
        self._mode = tk.StringVar(value="GCM")
        _combo(row2, self._mode, ["GCM", "CBC", "CTR", "ECB"], width=10).pack(side="left", padx=(0, 20))
        
        tk.Label(row2, text="--keysize", font=FS, bg=K, fg=DIM, width=10, anchor="e").pack(side="left", padx=5)
        self._ks = tk.StringVar(value="256")
        _combo(row2, self._ks, ["128", "192", "256"], width=10).pack(side="left")

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "ENCRYPT", self._enc, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "DECRYPT", self._dec, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "IMAGE_ECB_CBC_CTR", self._img_compare, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "AVALANCHE_1BIT", self._avalanche, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "NONCE_REUSE_CTR", self._nonce_reuse, accent=ERR).pack(side="left", padx=5)
        _btn(act_frame, "BENCHMARK_AES", self._benchmark, accent=SEL).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=15)
        self._log.pack(fill="both", expand=True, pady=5)

    def _enc(self):
        try:
            from aes_cipher import encrypt_text
            self._params = encrypt_text(self._txt.get(), mode=self._mode.get())
            _append(self._log, f"[{now()}] Mode : AES-{self._ks.get()}-{self._mode.get()}", "info")
            _append(self._log, f"[{now()}] Key  : {self._params['key'].hex()[:32]}…", "key")
            _append(self._log, f"[{now()}] CT   : {self._params['ciphertext'].hex()[:48]}…", "ok")
        except ImportError:
            try:
                key = secrets.token_bytes(int(self._ks.get()) // 8)
                ct, nonce, tag = aes_enc(self._txt.get().encode(), key)
                self._params = {"key": key, "ciphertext": ct, "nonce": nonce, "tag": tag, "mode": "GCM"}
                _append(self._log, f"[{now()}] [Direct pycryptodome fallback]", "warn")
                _append(self._log, f"[{now()}] Key : {key.hex()[:32]}…", "key")
                _append(self._log, f"[{now()}] CT  : {ct.hex()[:48]}…", "ok")
            except Exception as e2:
                _append(self._log, f"⚠ aes_cipher.py missing + fallback failed: {e2}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _dec(self):
        try:
            from aes_cipher import decrypt_text
            if not self._params:
                _append(self._log, "⚠ Encrypt first.", "warn"); return
            dec = decrypt_text(self._params)
            _append(self._log, f"[{now()}] Decrypted : {dec}", "ok")
        except ImportError:
            if self._params and "nonce" in self._params:
                try:
                    from Crypto.Cipher import AES
                    pt = aes_dec(self._params["ciphertext"], self._params["key"],
                                 self._params["nonce"], self._params["tag"])
                    _append(self._log, f"[{now()}] Decrypted : {pt.decode()}", "ok")
                except Exception as e2:
                    _append(self._log, f"Fallback error: {e2}", "err")
        except Exception as e:
            _append(self._log, f"Error: {e}", "err")

    def _img_compare(self):
        """Ex 2.3.1 — Modes ECB/CBC/CTR image comparison."""
        def _run():
            try:
                from aes_cipher import aes_image_mode_comparison
                self.after(0, lambda: _append(self._log, f"[{now()}] Génération des images ECB/CBC/CTR (Patientez)...", "warn"))
                res = aes_image_mode_comparison()
                if "error" in res:
                    self.after(0, lambda: _append(self._log, f"⚠ {res['error']}", "err"))
                    return
                self.after(0, lambda: (
                    _append(self._log, f"  Original : {res['original']}", "info"),
                    _append(self._log, f"  AES-ECB  : {res['ecb']}", "warn"),
                    _append(self._log, f"  AES-CBC  : {res['cbc']}", "ok"),
                    _append(self._log, f"  AES-CTR  : {res['ctr']}", "ok"),
                    _append(self._log, f"  Obs.     : {res['observation']}", "key")
                ))
            except ImportError:
                self.after(0, lambda: _append(self._log, "⚠ aes_cipher.py not found.", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Error: {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()

    def _avalanche(self):
        """Ex 2.3.2 — Avalanche en CBC (1-bit mod)."""
        def _run():
            try:
                from aes_cipher import avalanche_cbc_demo
                self.after(0, lambda: _append(self._log, f"[{now()}] Avalanche 1-bit sur CBC IV...", "warn"))
                res = avalanche_cbc_demo()
                self.after(0, lambda: (
                    _append(self._log, f"  Modif : {res['bit_flipped']}", "key"),
                    _append(self._log, f"  Diff. Bloc 0 : {res['diff_per_block'][0]:.1f}%", "warn"),
                    _append(self._log, f"  Diff. Bloc 1 : {res['diff_per_block'][1]:.1f}%", "warn"),
                    _append(self._log, f"  Diff moyenne : {res['avg_diff']:.1f}%", "ok")
                ))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Error: {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()

    def _nonce_reuse(self):
        """Ex 2.3.3 — Vulnérabilité nonce-reuse CTR."""
        def _run():
            try:
                from aes_cipher import ctr_nonce_reuse_attack
                self.after(0, lambda: _append(self._log, f"[{now()}] Attaque Nonce-Reuse (CTR)...", "warn"))
                m1 = b"MESSAGE SECRET 1"
                m2 = b"MESSAGE SECRET 2"
                res = ctr_nonce_reuse_attack(m1, m2)
                self.after(0, lambda: (
                    _append(self._log, f"  M1 (connu) : {m1.decode()}", "info"),
                    _append(self._log, f"  M2 (caché) : {m2.decode()}", "info"),
                    _append(self._log, f"  C1 ⊕ C2    : {res['xor_ciphertexts_hex'][:32]}…", "warn"),
                    _append(self._log, f"  M2 récupéré: {res['recovered_m2_text']}", "key" if res['attack_success'] else "err"),
                    _append(self._log, f"  Explication: {res['explanation'].splitlines()[0]}", "ok")
                ))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Error: {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()

    def _benchmark(self):
        """Ex 2.3.4 — Benchmark AES 128/192/256."""
        def _run():
            try:
                from aes_cipher import benchmark_aes_key_sizes
                self.after(0, lambda: _append(self._log, f"[{now()}] Benchmark AES (10 MB, CBC)...", "warn"))
                results = benchmark_aes_key_sizes(data_size_mb=10.0, mode="CBC", iterations=1)
                for r in results:
                    self.after(0, lambda res=r: _append(
                        self._log,
                        f"  AES-{res['key_size']} ({res['rounds']} tours) : {res['enc_throughput_mbs']:.1f} MB/s",
                        "ok" if res['key_size'] == 128 else "info"
                    ))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Error: {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()




# ═══════════════════════════════════════════════════════════════════════════
# AES FINALISTS (Ex 2.4)
# ═══════════════════════════════════════════════════════════════════════════

class AESFinalistsPanel(tk.Frame):
    FINALISTS = [
        ("Rijndael",  "SPN",    "128b block, 10/12/14 rounds, SubBytes+ShiftRows+MixColumns. Selected as AES in Oct 2000."),
        ("Twofish",   "Feistel","128b block, 16 rounds, key-dependent S-boxes, MDS matrix. Fast in software."),
        ("Serpent",   "SPN",    "128b block, 32 rounds. Highest security margin; lost to Rijndael on speed."),
        ("RC6",       "Feistel","128b block, 20 rounds, data-dependent rotations, integer multiplication."),
        ("MARS",      "Mixed",  "128b block, 32 rounds, heterogeneous mixing: add+XOR+rotate+S-box."),
    ]
    COLORS = [A, "#065f46", "#3b0764", "#78350f", "#1e1065"]

    def __init__(self, master):
        super().__init__(master, bg=K)
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/symmetric/aes_finalists", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: NIST Competition 1997–2000. Rijndael won due to speed, efficiency, and hardware viability.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Info block (flowing downwards)
        info_frame = tk.Frame(main, bg=K)
        info_frame.pack(fill="x", pady=5)
        
        for (name, struct, desc), color in zip(self.FINALISTS, self.COLORS):
            row = tk.Frame(info_frame, bg=K, pady=4)
            row.pack(fill="x")
            tk.Label(row, text=f"[*] {name.ljust(10)}", font=FBB, bg=K, fg=color).pack(side="left", padx=5)
            tk.Label(row, text=f"[{struct}] {desc}", font=FS, bg=K, fg=DIM).pack(side="left", padx=10)

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "ENCRYPT_ALL_5_DEMO", self._demo, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "BENCHMARK_1MB", self._benchmark, accent=SEL).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=12)
        self._log.pack(fill="both", expand=True, pady=5)

    def _demo(self):
        def _run():
            try:
                from aes_finalists import compare_all_finalists
                msg = b"AES finalist demo!!" * 2  # 32 bytes
                key = secrets.token_bytes(16)
                _append(self._log, f"[{now()}] Encrypting 32-byte msg with all 5 finalists:", "info")
                _append(self._log, f"  Key: {key.hex()}", "key")
                
                results = compare_all_finalists(msg, key)
                for name, ct_hex in results.items():
                    if "ERREUR" in ct_hex:
                        self.after(0, lambda n=name, err=ct_hex: _append(self._log, f"  {n:<10}: {err}", "err"))
                    else:
                        self.after(0, lambda n=name, h=ct_hex: _append(self._log, f"  {n:<10}: {h[:32]}…", "ok"))
                        
                self.after(0, lambda: _append(self._log, "  → Each finalist produces completely different ciphertext.", "info"))
                
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Error: {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()

    def _benchmark(self):
        def _run():
            try:
                from aes_finalists import benchmark_finalists
                _append(self._log, f"[{now()}] Benchmark 1 MB in progress (Pure Python, please wait)...", "warn")
                
                # 1 MB takes around 2-5 seconds in pure python
                results = benchmark_finalists(data_size_mb=1.0)
                
                self.after(0, lambda: _append(self._log, f"\n  {'Algorithm':<12} {'Structure':<20} {'Enc MB/s':>10} {'Dec MB/s':>10}", "info"))
                for r in results:
                    if "error" in r:
                        self.after(0, lambda res=r: _append(self._log, f"  {res['name']:<12} ERREUR: {res['error']}", "err"))
                    else:
                        color = "ok" if r['name'] == "Rijndael" else "key"
                        self.after(0, lambda res=r, c=color: _append(
                            self._log, 
                            f"  {res['name']:<12} {res['structure'][:18]:<20} {res['enc_throughput_mbs']:>10.2f} {res['dec_throughput_mbs']:>10.2f}", 
                            c
                        ))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Error: {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════
# CHIFFREMENT ASYMÉTRIQUE
# ═══════════════════════════════════════════════════════════════════════════

class AsymmetricSection(tk.Frame):
    ALGOS = ["RSA", "Diffie-Hellman", "ElGamal", "ECC"]

    def __init__(self, master, app: App):
        super().__init__(master, bg=K)
        self.app = app
        self._build()

    def _build(self):
        _section_hdr(self, "🗝", "Chiffrement Asymétrique",
                     "RSA · Diffie-Hellman · ElGamal")

        # Sub-navigation (Terminal Tab Style)
        sel_bar = tk.Frame(self, bg=K, padx=40, pady=0)
        sel_bar.pack(fill="x")
        
        tk.Label(sel_bar, text="SELECT_ALGO: ", font=FBB, bg=K, fg=DIM).pack(side="left")
        
        self._algo_var = tk.StringVar(value=self.ALGOS[0])
        for algo in self.ALGOS:
            rb = tk.Radiobutton(sel_bar, text=f" {algo} ", variable=self._algo_var,
                                value=algo, font=FBB, bg=K, fg=T,
                                selectcolor=SEL, activebackground=K,
                                activeforeground=T, cursor="hand2",
                                indicatoron=0, bd=1, relief="solid",
                                command=self._switch, pady=5, padx=10)
            rb.pack(side="left", padx=2)

        self._pages: dict[str, tk.Frame] = {}
        cont = tk.Frame(self, bg=K)
        cont.pack(fill="both", expand=True)
        for name, cls in [("RSA", RSAPanel), ("Diffie-Hellman", DHPanel),
                           ("ElGamal", ElGamalPanel), ("ECC", ECCPanel)]:
            p = cls(cont)
            p.place(relx=0, rely=0, relwidth=1, relheight=1)
            self._pages[name] = p
        self._switch()

    def _switch(self):
        sel = self._algo_var.get()
        for name, frame in self._pages.items():
            (frame.lift if name == sel else frame.lower)()


class RSAPanel(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=K)
        self._priv = self._pub = None
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/asymmetric/rsa", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Rivest-Shamir-Adleman. Public-Key Cryptography. Security based on factorization.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Input block
        inp_frame = tk.Frame(main, bg=K)
        inp_frame.pack(fill="x", pady=5)
        
        row1 = tk.Frame(inp_frame, bg=K); row1.pack(fill="x", pady=2)
        tk.Label(row1, text="--text", font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
        self._txt = tk.StringVar(value="Message secret RSA")
        _entry(row1, self._txt).pack(side="left", fill="x", expand=True)

        row2 = tk.Frame(inp_frame, bg=K); row2.pack(fill="x", pady=2)
        tk.Label(row2, text="--keysize", font=FS, bg=K, fg=DIM, width=8, anchor="e").pack(side="left", padx=5)
        self._bits = tk.StringVar(value="2048")
        _combo(row2, self._bits, ["1024", "2048", "4096"], width=10).pack(side="left")

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "GENERATE_KEYPAIR", self._keygen, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "ENCRYPT_OAEP", self._enc, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "DECRYPT_OAEP", self._dec, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "HYBRID_RSA_AES", self._hybrid, accent=SEL).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=18)
        self._log.pack(fill="both", expand=True, pady=5)

    def _keygen(self):
        bits = int(self._bits.get())
        _append(self._log, f"[{now()}] Génération RSA-{bits}…", "warn")
        def _run():
            try:
                from rsa_cipher import generate_keypair
                self._priv, self._pub = generate_keypair(bits)
                n_hex = hex(self._priv.n)
                self.after(0, lambda: _append(self._log,
                    f"[{now()}] Clé RSA-{bits} générée ✓\n  n = {n_hex[:20]}…", "ok"))
            except ImportError:
                if _CRYPTO:
                    self._priv, self._pub = rsa_keygen(bits)
                    self.after(0, lambda: _append(self._log,
                        f"[{now()}] Clé RSA-{bits} générée (fallback) ✓", "ok"))
                else:
                    self.after(0, lambda: _append(self._log, "⚠ pycryptodome requis.", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Erreur : {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()

    def _enc(self):
        try:
            if not self._pub:
                _append(self._log, "⚠ Générez les clés d'abord.", "warn"); return
            from rsa_cipher import encrypt_oaep
            ct = encrypt_oaep(self._txt.get().encode('utf-8'), self._pub)
            self._ct = ct
            _append(self._log, f"[{now()}] CT ({len(ct)} B) : {ct.hex()[:48]}…", "ok")
        except Exception as e:
            _append(self._log, f"Erreur : {e}", "err")

    def _dec(self):
        try:
            if not self._priv or not hasattr(self, "_ct"):
                _append(self._log, "⚠ Chiffrez d'abord.", "warn"); return
            from rsa_cipher import decrypt_oaep
            pt = decrypt_oaep(self._ct, self._priv)
            _append(self._log, f"[{now()}] Déchiffré : {pt.decode('utf-8')}", "ok")
        except Exception as e:
            _append(self._log, f"Erreur : {e}", "err")

    def _hybrid(self):
        def _run():
            try:
                from rsa_cipher import generate_keypair, hybrid_encrypt, hybrid_decrypt
                import time as _t
                if not self._priv:
                    self._priv, self._pub = generate_keypair(2048)
                payload = os.urandom(1024 * 1024)
                t0 = _t.perf_counter()
                bundle = hybrid_encrypt(payload, self._pub)
                pt     = hybrid_decrypt(bundle, self._priv)
                elapsed = (_t.perf_counter() - t0) * 1000
                ok = pt == payload
                self.after(0, lambda: (
                    _append(self._log, f"[{now()}] Hybride RSA-2048 + AES-256-GCM (1 Mo)", "info"),
                    _append(self._log, f"  RSA-OAEP (32 octets) : {bundle['t_rsa_ms']:.2f} ms", "key"),
                    _append(self._log, f"  AES-GCM  (1 Mo)     : {bundle['t_aes_ms']:.2f} ms", "key"),
                    _append(self._log, f"  Total                : {elapsed:.2f} ms", "info"),
                    _append(self._log, f"  Déchiffrement OK     : {ok} ✓", "ok")
                ))
            except ImportError:
                self.after(0, lambda: _append(self._log, "⚠ rsa_cipher.py non trouvé.", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Erreur : {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()


class DHPanel(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=K)
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/asymmetric/diffie_hellman", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Key Exchange on public channel. Vulnerable to MitM without ECDSA Authentication.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "EXCHANGE_ALICE_BOB", self._run, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "SIMULATE_MITM_ATTACK", self._mitm, accent=ERR).pack(side="left", padx=5)
        _btn(act_frame, "ECDSA_AUTHENTICATED_EXCHANGE", self._ecdsa_auth, accent=SEL).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=22)
        self._log.pack(fill="both", expand=True, pady=5)

    def _run(self):
        def _do():
            try:
                from diffie_hellman import DHParty
                _append(self._log, f"[{now()}] Génération des paramètres DH…", "warn")
                alice = DHParty()
                bob   = DHParty(p=alice.p, g=alice.g)
                ka = alice.derive_aes_key(bob.public_key)
                kb = bob.derive_aes_key(alice.public_key)
                self.after(0, lambda: (
                    _append(self._log, f"  p = {hex(alice.p)[:20]}… ({alice.p.bit_length()} bits)", "info"),
                    _append(self._log, f"  A (pub Alice) = {hex(alice.public_key)[:18]}…", "key"),
                    _append(self._log, f"  B (pub Bob)   = {hex(bob.public_key)[:18]}…", "key"),
                    _append(self._log, f"  Clé Alice : {ka.hex()}", "ok"),
                    _append(self._log, f"  Clé Bob   : {kb.hex()}", "ok"),
                    _append(self._log, f"  Identiques : {ka == kb} ✓", "ok")
                ))
            except ImportError:
                self.after(0, lambda: _append(self._log, "⚠ diffie_hellman.py non trouvé.", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Erreur : {e}", "err"))
        threading.Thread(target=_do, daemon=True).start()

    def _mitm(self):
        def _do():
            try:
                from diffie_hellman import DHParty
                _append(self._log, f"\n[{now()}] ══ Simulation attaque MitM ══", "warn")
                alice = DHParty()
                bob   = DHParty(p=alice.p, g=alice.g)
                eve   = DHParty(p=alice.p, g=alice.g)

                ka_eve = alice.derive_aes_key(eve.public_key)
                kb_eve = bob.derive_aes_key(eve.public_key)
                self.after(0, lambda: (
                    _append(self._log, "  Ève intercepte et substitue ses propres valeurs.", "warn"),
                    _append(self._log, f"  Clé Alice-Ève : {ka_eve.hex()[:24]}…", "err"),
                    _append(self._log, f"  Clé Bob-Ève   : {kb_eve.hex()[:24]}…", "err"),
                    _append(self._log, "  ⚠ Alice et Bob ont des clés DIFFÉRENTES !", "err"),
                    _append(self._log, "  ✓ Contre-mesure : signer les échanges (ECDSA)", "ok")
                ))
            except ImportError:
                self.after(0, lambda: _append(self._log, "⚠ diffie_hellman.py non trouvé.", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Erreur : {e}", "err"))
        threading.Thread(target=_do, daemon=True).start()

    def _ecdsa_auth(self):
        def _do():
            try:
                from diffie_hellman import AuthenticatedDHParty
                _append(self._log, f"\n[{now()}] ══ DH Authentifié avec ECDSA ══", "warn")
                alice = AuthenticatedDHParty("Alice")
                bob   = AuthenticatedDHParty("Bob", p=alice.p, g=alice.g)
                
                ka = alice.derive_aes_key(bob.dh_pub, bob.signature, bob.ecdsa_pub)
                kb = bob.derive_aes_key(alice.dh_pub, alice.signature, alice.ecdsa_pub)
                
                self.after(0, lambda: (
                    _append(self._log, f"  Signature d'Alice vérifiée par Bob : ✓", "ok"),
                    _append(self._log, f"  Signature de Bob vérifiée par Alice : ✓", "ok"),
                    _append(self._log, f"  Clé Alice : {ka.hex()[:32]}…", "ok"),
                    _append(self._log, f"  Clé Bob   : {kb.hex()[:32]}…", "ok"),
                    _append(self._log, f"  L'attaque MitM est mathématiquement bloquée.", "info")
                ))
            except ImportError:
                self.after(0, lambda: _append(self._log, "⚠ diffie_hellman.py non trouvé.", "err"))
            except ValueError as ve:
                self.after(0, lambda ve=ve: _append(self._log, f"Erreur de signature : {ve}", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Erreur : {e}", "err"))
        threading.Thread(target=_do, daemon=True).start()


class ElGamalPanel(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=K)
        self._eg = None
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/asymmetric/elgamal", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Probabilistic cipher based on Diffie-Hellman. Malleable property C = M * h^k.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Input block
        inp_frame = tk.Frame(main, bg=K)
        inp_frame.pack(fill="x", pady=5)
        
        row1 = tk.Frame(inp_frame, bg=K); row1.pack(fill="x", pady=2)
        tk.Label(row1, text="--msg_int", font=FS, bg=K, fg=DIM, width=10, anchor="e").pack(side="left", padx=5)
        self._m = tk.StringVar(value="12345")
        _entry(row1, self._m, width=20).pack(side="left")

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "GEN_KEYS_512B", self._keygen, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "ENCRYPT_MSG", self._enc, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "DEMO_NON_DETERMINISTIC", self._nondeter, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "DEMO_MALLEABILITY", self._malleability, accent=ERR).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=18)
        self._log.pack(fill="both", expand=True, pady=5)

    def _keygen(self):
        _append(self._log, f"[{now()}] Génération ElGamal-512…", "warn")
        def _run():
            try:
                from elgamal import ElGamal
                self._eg = ElGamal(bits=512)
                p, g, h  = self._eg.public_key
                self.after(0, lambda: (
                    _append(self._log, f"[{now()}] p = {hex(p)[:18]}… ({p.bit_length()} bits)", "key"),
                    _append(self._log, f"  g = {g}", "info"),
                    _append(self._log, f"  h = {hex(h)[:18]}… (clé publique)", "ok")
                ))
            except ImportError:
                self.after(0, lambda: _append(self._log, "⚠ elgamal.py non trouvé.", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Erreur : {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()

    def _enc(self):
        try:
            if not self._eg:
                _append(self._log, "⚠ Générez les clés d'abord.", "warn"); return
            M = int(self._m.get())
            C1, C2 = self._eg.encrypt_int(M)
            self._last = (C1, C2)
            dec = self._eg.decrypt_int(C1, C2)
            _append(self._log, f"[{now()}] M = {M}", "info")
            _append(self._log, f"  C1 = {hex(C1)[:20]}…", "ok")
            _append(self._log, f"  C2 = {hex(C2)[:20]}…", "ok")
            _append(self._log, f"  D(E(M)) = {dec}  ✓", "ok")
        except Exception as e:
            _append(self._log, f"Erreur : {e}", "err")

    def _nondeter(self):
        try:
            if not self._eg:
                _append(self._log, "⚠ Générez les clés d'abord.", "warn"); return
            M  = int(self._m.get())
            E1 = self._eg.encrypt_int(M)
            E2 = self._eg.encrypt_int(M)
            _append(self._log, f"[{now()}] Non-déterminisme (même M={M}) :", "info")
            _append(self._log, f"  Enc₁ = ({hex(E1[0])[:12]}…, {hex(E1[1])[:12]}…)", "key")
            _append(self._log, f"  Enc₂ = ({hex(E2[0])[:12]}…, {hex(E2[1])[:12]}…)", "key")
            _append(self._log, f"  Égaux : {E1 == E2}  ← k différent à chaque chiffrement", "ok")
        except Exception as e:
            _append(self._log, f"Erreur : {e}", "err")

    def _malleability(self):
        try:
            if not self._eg or not hasattr(self, "_last"):
                _append(self._log, "⚠ Chiffrez M d'abord.", "warn"); return
            M = int(self._m.get())
            C1, C2 = self._last
            forged  = (C1, (2 * C2) % self._eg.p)
            dec_f   = self._eg.decrypt_int(*forged)
            expected = (2 * M) % self._eg.p
            _append(self._log, f"[{now()}] Malléabilité : E(2M) forgé sans connaître M ni x", "warn")
            _append(self._log, f"  D(forgé) = {dec_f}", "info")
            _append(self._log, f"  2M mod p = {expected}", "info")
            _append(self._log, f"  Succès   : {dec_f == expected} ✓", "ok")
        except Exception as e:
            _append(self._log, f"Erreur : {e}", "err")


class ECCPanel(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg=K)
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/asymmetric/ecc", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Elliptic Curve Cryptography. ECDH (P-256) & ECIES. Smaller keys, high security (ECC-256 ≈ RSA-3072).", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Input block
        inp_frame = tk.Frame(main, bg=K)
        inp_frame.pack(fill="x", pady=5)
        
        row1 = tk.Frame(inp_frame, bg=K); row1.pack(fill="x", pady=2)
        tk.Label(row1, text="--message", font=FS, bg=K, fg=DIM, width=10, anchor="e").pack(side="left", padx=5)
        self._txt = tk.StringVar(value="Message secret via ECIES")
        _entry(row1, self._txt).pack(side="left", fill="x", expand=True)

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "DEMO_TINY_CURVE", self._tiny, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "ECDH_P256", self._ecdh, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "ECIES_ENCRYPT_DECRYPT", self._ecies, accent=SEL).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=18)
        self._log.pack(fill="both", expand=True, pady=5)

    def _tiny(self):
        def _run():
            try:
                from ecc import TinyEllipticCurve
                curve = TinyEllipticCurve(0, 7, 97)
                G = (1, 28)
                lines = [f"[{now()}] Courbe y²=x³+7 (mod 97), G={G}"]
                for k in [1, 2, 3, 5, 7, 10]:
                    kG = curve.scalar_mul(k, G)
                    lines.append(f"  {k:>2}·G = {str(kG):<20}  sur courbe: {curve.is_on_curve(kG)}")
                P = curve.scalar_mul(3, G)
                Q = curve.scalar_mul(5, G)
                R = curve.point_add(P, Q)
                lines.append(f"  3G + 5G = {R}  (= 8G = {curve.scalar_mul(8,G)}) ✓")
                self.after(0, lambda: [_append(self._log, l, "info") for l in lines])
            except ImportError:
                self.after(0, lambda: _append(self._log, "⚠ ecc.py non trouvé.", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Erreur : {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()

    def _ecdh(self):
        def _run():
            try:
                from ecc import ECDHParty
                alice = ECDHParty("Alice")
                bob   = ECDHParty("Bob")
                ka    = alice.derive_aes_key(bob.pub)
                kb    = bob.derive_aes_key(alice.pub)
                match = ka == kb
                self.after(0, lambda: (
                    _append(self._log, f"[{now()}] ECDH P-256", "info"),
                    _append(self._log, f"  Clé Alice : {ka.hex()}", "key"),
                    _append(self._log, f"  Clé Bob   : {kb.hex()}", "key"),
                    _append(self._log, f"  Identiques : {match} ✓", "ok")
                ))
            except ImportError:
                self.after(0, lambda: _append(self._log, "⚠ ecc.py non trouvé.", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Erreur : {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()

    def _ecies(self):
        def _run():
            try:
                from ecc import ECDHParty, ecies_encrypt, ecies_decrypt
                bob   = ECDHParty("Bob")
                msg   = self._txt.get().encode()
                bundle = ecies_encrypt(msg, bob.pub)
                recovered = ecies_decrypt(bundle, bob)
                self.after(0, lambda: (
                    _append(self._log, f"[{now()}] ECIES : {self._txt.get()}", "info"),
                    _append(self._log, f"  Nonce : {bundle['nonce'].hex()}", "key"),
                    _append(self._log, f"  CT    : {bundle['ciphertext'].hex()[:40]}…", "ok"),
                    _append(self._log, f"  Tag   : {bundle['tag'].hex()}", "key"),
                    _append(self._log, f"  Déchiffré : {recovered.decode()}", "ok"),
                    _append(self._log, f"  PFS : clé éphémère détruite ✓", "ok")
                ))
            except ImportError:
                self.after(0, lambda: _append(self._log, "⚠ ecc.py non trouvé.", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Erreur : {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════
# HACHAGE
# ═══════════════════════════════════════════════════════════════════════════

class HashSection(tk.Frame):
    def __init__(self, master, app: App):
        super().__init__(master, bg=K)
        self.app = app
        self._build()

    def _build(self):
        _section_hdr(self, "#", "Fonctions de Hachage",
                     "MD5 · SHA-256 · SHA-512 · SHA-3 · HMAC — avalanche, intégrité, benchmark")

        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/hash/analysis", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: One-way functions. Properties: Pre-image resistance, collision resistance. HMAC for integrity.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Input block
        inp_frame = tk.Frame(main, bg=K)
        inp_frame.pack(fill="x", pady=5)
        
        row1 = tk.Frame(inp_frame, bg=K); row1.pack(fill="x", pady=2)
        tk.Label(row1, text="--message", font=FS, bg=K, fg=DIM, width=10, anchor="e").pack(side="left", padx=5)
        self._txt = tk.StringVar(value="Hello, Cryptographie!")
        _entry(row1, self._txt).pack(side="left", fill="x", expand=True)

        row2 = tk.Frame(inp_frame, bg=K); row2.pack(fill="x", pady=2)
        tk.Label(row2, text="--hmac_key", font=FS, bg=K, fg=DIM, width=10, anchor="e").pack(side="left", padx=5)
        self._hmac_key = tk.StringVar(value="cle_secrete")
        _entry(row2, self._hmac_key).pack(side="left", fill="x", expand=True)

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "HASH_ALL", self._hash_all, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "AVALANCHE_EFFECT", self._avalanche, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "HMAC_SHA256", self._hmac, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "SHA256_PURE_PYTHON", self._sha256_pure, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "INTEGRITY_CHECK", self._integrity_check, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "BENCHMARK_100MB", self._benchmark_hash, accent=ERR).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=22)
        self._log.pack(fill="both", expand=True, pady=5)

    def _hash_all(self):
        def _do():
            try:
                import hashlib
                import time as _t
                msg = self._txt.get().encode()
                msg2 = bytearray(msg) if msg else bytearray(b"\x00")
                if msg: msg2[0] ^= 0x01
                msg2 = bytes(msg2)
                
                self.after(0, lambda: _append(self._log, f"\n[{now()}] ══ Comparaison MD5, SHA-256, SHA-512 ══", "warn"))
                self.after(0, lambda: _append(self._log, f"  Message : {msg.decode('utf-8', 'replace')[:30]}…", "info"))
                
                for algo in ["md5", "sha256", "sha512"]:
                    # Benchmark (loop 10,000 times for accurate microsecond timing)
                    t0 = _t.perf_counter()
                    for _ in range(10000):
                        h = hashlib.new(algo, msg).hexdigest()
                    dt = (_t.perf_counter() - t0) / 10000.0 * 1e6
                    
                    bits = len(h) * 4
                    self.after(0, lambda a=algo, b=bits, t=dt: 
                        _append(self._log, f"  {a.upper():<7}: Sortie = {b} bits | Temps = {t:.2f} µs", "key"))
                        
                    # Avalanche effect (1 bit flipped)
                    h1 = int(h, 16)
                    h2 = int(hashlib.new(algo, msg2).hexdigest(), 16)
                    diff = bin(h1 ^ h2).count("1")
                    pct = (diff / bits) * 100
                    self.after(0, lambda a=algo, d=diff, b=bits, p=pct:
                        _append(self._log, f"    ↳ Avalanche : {d:>3}/{b} bits modifiés ({p:.1f}%)", "hash"))
                        
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Erreur : {e}", "err"))
        threading.Thread(target=_do, daemon=True).start()

    def _avalanche(self):
        def _do():
            try:
                import hashlib
                import os
                self.after(0, lambda: _append(self._log, f"\n[{now()}] ══ Exercice 4.1 : MD5 & Effet Avalanche ══", "warn"))
                
                messages = [
                    ("Chaîne vide", b""),
                    ("1 octet", b"\x42"),
                    ("1 Ko", os.urandom(1024)),
                    ("1 Mo", os.urandom(1024 * 1024)),
                    ("Binaire (pattern)", bytes(range(256)) * 4)
                ]
                
                self.after(0, lambda: _append(self._log, "[1] Vérification de la taille de sortie (128 bits = 32 hex)", "info"))
                
                for label, msg in messages:
                    d = hashlib.md5(msg).hexdigest()
                    bits = len(d) * 4
                    self.after(0, lambda l=label, s=len(msg), d_=d, b=bits: 
                        _append(self._log, f"  {l:<18} ({s:>7} B) : {d_[:16]}…  → {b} bits ✓", "hash"))
                
                self.after(0, lambda: _append(self._log, "\n[2] Effet Avalanche (1 bit modifié, cible ≈ 50%)", "info"))
                
                for label, msg in messages:
                    ba = bytearray(msg) if msg else bytearray(b"\x00")
                    ba[0] ^= 0x01
                    msg2 = bytes(ba)
                    
                    h1 = int(hashlib.md5(msg if msg else b"").hexdigest(), 16)
                    h2 = int(hashlib.md5(msg2).hexdigest(), 16)
                    
                    diff = bin(h1 ^ h2).count("1")
                    pct = (diff / 128.0) * 100
                    
                    color = "ok" if 40 <= pct <= 60 else "warn"
                    self.after(0, lambda l=label, d=diff, p=pct, c=color: 
                        _append(self._log, f"  {l:<18} : {d:>3}/128 bits changés ({p:5.1f}%)", c))
                        
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Erreur : {e}", "err"))
                
        threading.Thread(target=_do, daemon=True).start()

    def _hmac(self):
        import hmac as _hmac, hashlib
        key = self._hmac_key.get().encode()
        msg = self._txt.get().encode()
        mac = _hmac.new(key, msg, hashlib.sha256).hexdigest()
        _append(self._log, f"[{now()}] HMAC-SHA256 :", "info")
        _append(self._log, f"  Clé : {self._hmac_key.get()}", "key")
        _append(self._log, f"  MAC : {mac}", "ok")

        # Verify
        valid = _hmac.compare_digest(
            _hmac.new(key, msg, hashlib.sha256).hexdigest(), mac)
        tampered_valid = _hmac.compare_digest(
            _hmac.new(key, msg + b"X", hashlib.sha256).hexdigest(), mac)
        _append(self._log, f"  Vérif. msg original : {valid} ✓", "ok")
        _append(self._log, f"  Vérif. msg altéré   : {tampered_valid} ✗", "err")

    def _sha256_pure(self):
        def _run():
            try:
                from sha256_pure import sha256_hex
                import hashlib
                _append(self._log, f"[{now()}] SHA-256 pure Python vs hashlib:", "info")
                msg = self._txt.get().encode()
                mine  = sha256_hex(msg)
                ref   = hashlib.sha256(msg).hexdigest()
                match = mine == ref
                self.after(0, lambda: (
                    _append(self._log, f"  pure Python : {mine}", "hash"),
                    _append(self._log, f"  hashlib     : {ref}", "hash"),
                    _append(self._log, f"  Match       : {match} ✓", "ok")
                ))
            except ImportError:
                self.after(0, lambda: _append(self._log, "⚠ sha256_pure.py not found.", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Error: {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()

    def _integrity_check(self):
        """Ex 4.2.2 — Simulate SHA-256 file integrity verification."""
        import hashlib
        # Simulate a 'download': create a fake 64 KB payload
        data    = (self._txt.get() * 512).encode()[:65536]
        official_hash = hashlib.sha256(data).hexdigest()  # "published" hash
        # Simulate local file (same data — OK case)
        local_hash = hashlib.sha256(data).hexdigest()
        status_ok  = local_hash == official_hash
        _append(self._log, f"[{now()}] Integrity Check (Ex 4.2.2)", "info")
        _append(self._log, f"  Published SHA-256 : {official_hash[:32]}…", "key")
        _append(self._log, f"  Local     SHA-256 : {local_hash[:32]}…", "hash")
        _append(self._log, f"  Status : {'OK ✓' if status_ok else 'CORRUPTED ✗'}",
                "ok" if status_ok else "err")
        # Simulate tampered file
        tampered  = bytearray(data); tampered[0] ^= 0x01
        tam_hash  = hashlib.sha256(bytes(tampered)).hexdigest()
        tam_ok    = tam_hash == official_hash
        _append(self._log, f"  Tampered SHA-256  : {tam_hash[:32]}…", "warn")
        _append(self._log, f"  Tampered status   : {'OK' if tam_ok else 'CORRUPTED ✗'}",
                "ok" if tam_ok else "err")

    def _benchmark_hash(self):
        """Ex 4.3.2 — Hash benchmark on 100 MB."""
        def _run():
            import hashlib, time as _t
            data = os.urandom(100 * 1024 * 1024)  # 100 MB
            _append(self._log, f"[{now()}] Hashing 100 MB…", "warn")
            for algo in ["md5", "sha256", "sha512", "sha3_256"]:
                t0 = _t.perf_counter()
                hashlib.new(algo, data).hexdigest()
                elapsed = _t.perf_counter() - t0
                mbps = 100 / elapsed if elapsed > 0 else 0
                self.after(0, lambda a=algo, ms=elapsed*1000, m=mbps:
                    _append(self._log, f"  {a:<12}: {ms:.0f} ms  ({m:.0f} MB/s)", "key"))
            self.after(0, lambda: _append(self._log,
                "  SHA-512 fastest on 64-bit CPUs (wider word ops).", "ok"))
        threading.Thread(target=_run, daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════
# SIGNATURES NUMÉRIQUES
# ═══════════════════════════════════════════════════════════════════════════

class SignatureSection(tk.Frame):
    def __init__(self, master, app: App):
        super().__init__(master, bg=K)
        self.app = app
        self._build()

    def _build(self):
        _section_hdr(self, "✍", "Signatures Numériques",
                     "RSA-PSS · ElGamal · DSA · ECDSA — authenticité, intégrité, non-répudiation")

        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/signature/algorithms", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Digital Signatures ensure authenticity, integrity, and non-repudiation. Verify(PK, M, S) -> {0,1}", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Input block
        inp_frame = tk.Frame(main, bg=K)
        inp_frame.pack(fill="x", pady=5)
        
        row1 = tk.Frame(inp_frame, bg=K); row1.pack(fill="x", pady=2)
        tk.Label(row1, text="--message", font=FS, bg=K, fg=DIM, width=10, anchor="e").pack(side="left", padx=5)
        self._txt = tk.StringVar(value="Document à signer officiellement")
        _entry(row1, self._txt).pack(side="left", fill="x", expand=True)

        row2 = tk.Frame(inp_frame, bg=K); row2.pack(fill="x", pady=2)
        tk.Label(row2, text="--scheme", font=FS, bg=K, fg=DIM, width=10, anchor="e").pack(side="left", padx=5)
        self._scheme = tk.StringVar(value="RSA-PSS")
        _combo(row2, self._scheme, ["RSA-PSS", "RSA-PKCS#1 v1.5", "ElGamal", "DSA", "ECDSA (P-256)"], width=16).pack(side="left")

        # Action block
        act_frame = tk.Frame(main, bg=S, pady=10, padx=20)
        act_frame.pack(fill="x", pady=15)
        
        tk.Label(act_frame, text="[ ACTIONS ]", font=FS, bg=S, fg=DIM).pack(side="left", padx=(0, 20))
        _btn(act_frame, "SIGN", self._sign, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "VERIFY_ORIGINAL", self._verify_original, accent=SEL).pack(side="left", padx=5)
        _btn(act_frame, "VERIFY_TAMPERED", self._verify_tampered_msg, accent=ERR).pack(side="left", padx=5)

        # Log block
        tk.Label(main, text="OUTPUT_STREAM:", font=FBB, bg=K, fg=DIM).pack(anchor="w", pady=(10, 0))
        self._log = _log(main, height=20)
        self._log.pack(fill="both", expand=True, pady=5)

    def _sign(self):
        scheme = self._scheme.get()
        msg    = self._txt.get()
        _append(self._log, f"[{now()}] Signature {scheme}…", "warn")
        def _run():
            try:
                if scheme.startswith("RSA"):
                    from rsa_cipher import generate_keypair, sign, sign_pkcs1_v1_5
                    self._priv_s, self._pub_s = generate_keypair(2048)
                    if scheme == "RSA-PSS":
                        self._sig = sign(msg.encode(), self._priv_s)
                    else:
                        self._sig = sign_pkcs1_v1_5(msg.encode(), self._priv_s)
                    self.after(0, lambda: (
                        _append(self._log, f"[{now()}] {scheme} 2048-bit", "info"),
                        _append(self._log, f"  Sig ({len(self._sig)} B) : {self._sig.hex()[:48]}…", "ok")
                    ))
                elif scheme == "ElGamal":
                    from signature import ElGamalSignature
                    self._elgamal = ElGamalSignature(bits=512)
                    self._sig_eg = self._elgamal.sign(msg)
                    self.after(0, lambda: (
                        _append(self._log, f"[{now()}] ElGamal 512-bit", "info"),
                        _append(self._log, f"  Sig r : {hex(self._sig_eg[0])[:30]}…", "ok"),
                        _append(self._log, f"  Sig s : {hex(self._sig_eg[1])[:30]}…", "ok")
                    ))
                elif scheme == "DSA":
                    from signature import DSASignature
                    self._dsa = DSASignature(bits=1024)
                    self._sig_dsa = self._dsa.sign(msg)
                    self.after(0, lambda: (
                        _append(self._log, f"[{now()}] DSA 1024-bit", "info"),
                        _append(self._log, f"  Signature : {self._sig_dsa.hex()[:50]}…", "ok")
                    ))
                elif scheme == "ECDSA (P-256)":
                    from signature import ECDSASignature
                    self._ecdsa = ECDSASignature("P-256")
                    self._sig_ec = self._ecdsa.sign(msg)
                    self.after(0, lambda: (
                        _append(self._log, f"[{now()}] ECDSA P-256", "info"),
                        _append(self._log, f"  Signature : {self._sig_ec.hex()[:50]}…", "ok")
                    ))
            except ImportError as ie:
                self.after(0, lambda ie=ie: _append(self._log, f"⚠ Module manquant : {ie}", "err"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._log, f"Erreur : {e}", "err"))
        threading.Thread(target=_run, daemon=True).start()

    def _verify(self, tampered=False):
        try:
            scheme = self._scheme.get()
            msg    = self._txt.get() + (" [ALTÉRÉ]" if tampered else "")
            ok = False
            if scheme.startswith("RSA"):
                from rsa_cipher import verify_signature, verify_pkcs1_v1_5
                if not hasattr(self, "_sig"):
                    _append(self._log, "⚠ Signez d'abord.", "warn"); return
                if scheme == "RSA-PSS":
                    ok = verify_signature(msg.encode(), self._sig, self._pub_s)
                else:
                    ok = verify_pkcs1_v1_5(msg.encode(), self._sig, self._pub_s)
            elif scheme == "ElGamal":
                if not hasattr(self, "_sig_eg"):
                    _append(self._log, "⚠ Signez d'abord.", "warn"); return
                ok = self._elgamal.verify(msg, self._sig_eg)
            elif scheme == "DSA":
                from signature import DSASignature
                if not hasattr(self, "_sig_dsa"):
                    _append(self._log, "⚠ Signez d'abord.", "warn"); return
                ok = DSASignature.verify(msg, self._sig_dsa, self._dsa.public_key)
            elif scheme == "ECDSA (P-256)":
                from signature import ECDSASignature
                if not hasattr(self, "_sig_ec"):
                    _append(self._log, "⚠ Signez d'abord.", "warn"); return
                ok = ECDSASignature.verify(msg, self._sig_ec, self._ecdsa.public_key)

            label = "altéré" if tampered else "original"
            status = "✓" if ok else "✗"
            color = "ok" if ok and not tampered else "err"
            if not ok and tampered: color = "ok" # Tampered failed verify is a GOOD thing (shows integrity)
            _append(self._log, f"[{now()}] Vérif. {scheme} ({label}) : {ok} {status}", color)
            
        except ImportError as ie:
            _append(self._log, f"⚠ Module manquant : {ie}", "err")
        except Exception as e:
            _append(self._log, f"Erreur : {e}", "err")

    def _verify_original(self): self._verify(tampered=False)
    def _verify_tampered_msg(self): self._verify(tampered=True)


# ═══════════════════════════════════════════════════════════════════════════
# COMMUNICATIONS SÉCURISÉES (ex gui_tp6)
# ═══════════════════════════════════════════════════════════════════════════

class CommsSection(tk.Frame):
    SUB_NAV = [
        ("🔌", "TCP / IP",  "tcp"),
        ("📡", "Bluetooth", "bt"),
        ("💬", "UDP Chat",  "udp"),
        ("🗳",  "Vote",      "vote"),
    ]

    def __init__(self, master, app: App):
        super().__init__(master, bg=K)
        self.app = app
        self._build()

    def _build(self):
        _section_hdr(self, "🌐", "Communications Sécurisées",
                     "TCP/IP · Bluetooth · UDP Chat · Vote homomorphe (Paillier)")

        # Sub-navigation (Terminal Tab Style)
        sel_bar = tk.Frame(self, bg=K, padx=40, pady=0)
        sel_bar.pack(fill="x")
        
        tk.Label(sel_bar, text="SELECT_COMMS: ", font=FBB, bg=K, fg=DIM).pack(side="left")
        
        self._sub_var = tk.StringVar(value="tcp")
        for icon, label, key in self.SUB_NAV:
            rb = tk.Radiobutton(sel_bar, text=f" [{key.upper()}] ", variable=self._sub_var,
                                value=key, font=FBB, bg=K, fg=T,
                                selectcolor=SEL, activebackground=K,
                                activeforeground=T, cursor="hand2",
                                indicatoron=0, bd=1, relief="solid",
                                command=self._switch_sub, pady=5, padx=5)
            rb.pack(side="left", padx=2)

        self._pages: dict[str, tk.Frame] = {}
        cont = tk.Frame(self, bg=K)
        cont.pack(fill="both", expand=True)
        for key, cls in [("tcp", TCPSection), ("bt", BTSection),
                          ("udp", UDPSection), ("vote", VoteSection)]:
            p = cls(cont, self.app)
            p.place(relx=0, rely=0, relwidth=1, relheight=1)
            self._pages[key] = p
        self._switch_sub()

    def _switch_sub(self):
        sel = self._sub_var.get()
        for name, frame in self._pages.items():
            (frame.lift if name == sel else frame.lower)()


# ── TCP Section (preserved from original) ─────────────────────────────────

class TCPSection(tk.Frame):
    def __init__(self, master, app: App):
        super().__init__(master, bg=K)
        self.app      = app
        self._s_sock  = self._s_conn = self._c_sock = None
        self._s_key   = self._c_key  = None
        self._running = False
        self._sq: queue.Queue = queue.Queue()
        self._cq: queue.Queue = queue.Queue()
        self._build()
        self._poll()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/comms/tcp_ip", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Secure TCP Chat. Handshake via RSA-2048, Encrypted via AES-256-GCM.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Split Pane — Nova (server) and Orion (client)
        split_frame = tk.Frame(main, bg=K)
        split_frame.pack(fill="both", expand=True, pady=5)
        split_frame.grid_columnconfigure(0, weight=1)
        split_frame.grid_columnconfigure(1, weight=1)
        split_frame.grid_rowconfigure(0, weight=1)

        self._alice_pane = self._peer(split_frame, "NOVA (SERVER)", True)
        self._alice_pane.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self._bob_pane = self._peer(split_frame, "ORION (CLIENT)", False)
        self._bob_pane.grid(row=0, column=1, sticky="nsew", padx=(10, 0))

        # Protocol Log
        plog_f = tk.Frame(main, bg=K)
        plog_f.pack(fill="x", pady=15)
        tk.Label(plog_f, text="PROTOCOL_TELEMETRY:", font=FBB, bg=K, fg=DIM).pack(anchor="w")
        self._plog = _log(plog_f, height=5)
        self._plog.pack(fill="x", pady=5)

    def _peer(self, parent, title, is_server):
        pane = tk.Frame(parent, bg=C, highlightbackground=S, highlightthickness=1)
        
        # Header
        bar = tk.Frame(pane, bg=S, padx=10, pady=5)
        bar.pack(fill="x")
        tk.Label(bar, text=f"[{title}]", font=FBB, bg=S, fg=T).pack(side="left")
        st_var = tk.StringVar(value="[DISCONNECTED]")
        st_lbl = tk.Label(bar, textvariable=st_var, font=FBB, bg=S, fg=WRN)
        st_lbl.pack(side="right")

        # Controls
        ctrl = tk.Frame(pane, bg=C, padx=10, pady=10)
        ctrl.pack(fill="x")
        if is_server:
            self._a_st = st_var; self._a_st_lbl = st_lbl
            self._port_var = tk.StringVar(value=str(TCP_PORT))
            tk.Label(ctrl, text="--port", font=FS, bg=C, fg=DIM).pack(side="left", padx=(0, 5))
            tk.Entry(ctrl, textvariable=self._port_var, width=6, bg=INP, fg=T, insertbackground=T, bd=0, font=FM).pack(side="left")
            self._srv_btn = _btn(ctrl, "START_SERVER", self._toggle_server, accent=SEL)
            self._srv_btn.pack(side="left", padx=10)
        else:
            self._b_st = st_var; self._b_st_lbl = st_lbl
            self._conn_btn = _btn(ctrl, "CONNECT", self._connect_client, accent=MUT, fg=DIM)
            self._conn_btn.pack(side="left")

        # Log
        log = _log(pane, height=12)
        log.pack(fill="both", expand=True, padx=10, pady=5)

        # Input
        ir = tk.Frame(pane, bg=C, padx=10, pady=10)
        ir.pack(fill="x")
        msg_var = tk.StringVar()
        e = _entry(ir, msg_var)
        e.pack(side="left", fill="x", expand=True)
        cmd = self._send_server if is_server else self._send_client
        if is_server: self._a_log = log; self._a_msg = msg_var
        else:          self._b_log = log; self._b_msg = msg_var
        sb = _btn(ir, "SEND", cmd, accent=SEL)
        sb.pack(side="right", padx=(10, 0))
        e.bind("<Return>", lambda _: cmd())
        return pane

    def _toggle_server(self):
        if not self._running:
            self._running = True
            self._srv_btn.configure(text="Arrêter", bg=ERR)
            port = int(self._port_var.get())
            self._sq.put(("sys", f"[{now()}] Serveur démarré port {port}…"))
            self._plog_put(f"[{now()}] SERVER bind 127.0.0.1:{port}", "info")
            threading.Thread(target=self._srv_fn, args=(port,), daemon=True).start()
        else:
            self._running = False
            for s in (self._s_conn, self._s_sock):
                try: s and s.close()
                except: pass
            self._s_key = None
            self._srv_btn.configure(text="Démarrer", bg=A)
            self._a_st.set("○ Déconnecté"); self._a_st_lbl.configure(fg=WRN)

    def _srv_fn(self, port):
        try:
            self._s_sock = socket.socket()
            self._s_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._s_sock.bind(("127.0.0.1", port))
            self._s_sock.listen(1)
            self._sq.put(("st", "● En attente…", WRN))
            conn, addr = self._s_sock.accept()
            self._s_conn = conn
            self._sq.put(("sys", f"[{now()}] Connexion {addr[0]}:{addr[1]}"))
            self._plog_put(f"[{now()}] TCP connexion de {addr}", "ok")
            priv, pub = rsa_keygen(2048)
            if priv:
                pub_pem = pub.export_key()
                _send_frame(conn, pub_pem)
                self._plog_put(f"[{now()}] → pub RSA-2048 ({len(pub_pem)} B)", "info")
                enc_key = _recv_frame(conn)
                self._s_key = rsa_dec(enc_key, priv)
                self._plog_put(f"[{now()}] HANDSHAKE OK  clé={self._s_key.hex()[:24]}…", "ok")
            else:
                _send_frame(conn, b"NO_RSA"); _recv_frame(conn)
                self._s_key = hashlib.sha256(b"fallback").digest()
                self._plog_put(f"[{now()}] MODE DÉGRADÉ", "warn")
            self._sq.put(("st", "● Connecté", OK))
            self._sq.put(("enable_conn_btn", None, None))
            while self._running:
                conn.settimeout(0.5)
                try:
                    frame = _recv_frame(conn)
                    if not frame: break
                    nonce, tag, ct = frame[:16], frame[16:32], frame[32:]
                    msg = aes_dec(ct, self._s_key, nonce, tag).decode()
                    self._sq.put(("recv", f"[{now()}] 📨 Orion : {msg}"))
                except socket.timeout: continue
                except: break
        except Exception as e:
            if self._running:
                self._sq.put(("err", f"[{now()}] Erreur serveur : {e}"))

    def _send_server(self):
        msg = self._a_msg.get().strip()
        if not msg or not self._s_conn or not self._s_key: return
        ct, nonce, tag = aes_enc(msg.encode(), self._s_key)
        try:
            _send_frame(self._s_conn, nonce + tag + ct)
            _append(self._a_log, f"[{now()}] 🔒 Vous : {msg}", "sent")
            self._a_msg.set("")
        except Exception as e:
            _append(self._a_log, f"[{now()}] Erreur : {e}", "err")

    def _connect_client(self):
        if self._c_sock: return
        port = int(self._port_var.get())
        _append(self._b_log, f"[{now()}] Connexion à 127.0.0.1:{port}…", "sys")
        threading.Thread(target=self._cli_fn, args=(port,), daemon=True).start()

    def _cli_fn(self, port):
        try:
            s = socket.socket()
            s.connect(("127.0.0.1", port))
            self._c_sock = s
            self._cq.put(("sys", f"[{now()}] Connecté au serveur."))
            pub_pem = _recv_frame(s)
            if pub_pem == b"NO_RSA":
                _send_frame(s, b"OK")
                self._c_key = hashlib.sha256(b"fallback").digest()
            else:
                from Crypto.PublicKey import RSA as _R
                srv_pub = _R.import_key(pub_pem)
                self._c_key = secrets.token_bytes(32)
                enc_k = rsa_enc(self._c_key, srv_pub)
                _send_frame(s, enc_k)
                self._plog_put(f"[{now()}] HANDSHAKE OK  clé={self._c_key.hex()[:24]}…", "ok")
            self._cq.put(("st", "● Connecté", OK))
            while True:
                s.settimeout(0.5)
                try:
                    frame = _recv_frame(s)
                    if not frame: break
                    nonce, tag, ct = frame[:16], frame[16:32], frame[32:]
                    msg = aes_dec(ct, self._c_key, nonce, tag).decode()
                    self._cq.put(("recv", f"[{now()}] 📨 Nova : {msg}"))
                except socket.timeout: continue
                except: break
        except Exception as e:
            self._cq.put(("err", f"[{now()}] Erreur client : {e}"))

    def _send_client(self):
        msg = self._b_msg.get().strip()
        if not msg or not self._c_sock or not self._c_key: return
        ct, nonce, tag = aes_enc(msg.encode(), self._c_key)
        try:
            _send_frame(self._c_sock, nonce + tag + ct)
            _append(self._b_log, f"[{now()}] 🔒 Vous : {msg}", "sent")
            self._b_msg.set("")
        except Exception as e:
            _append(self._b_log, f"[{now()}] Erreur : {e}", "err")

    def _plog_put(self, msg, tag=""):
        self._sq.put(("__plog__", msg, tag))

    def _poll(self):
        for q, log, st_var, st_lbl in [
            (self._sq, self._a_log, self._a_st, self._a_st_lbl),
            (self._cq, self._b_log, self._b_st, self._b_st_lbl),
        ]:
            while not q.empty():
                try:
                    item = q.get_nowait()
                    kind = item[0]
                    if kind == "sys":    _append(log, item[1], "sys")
                    elif kind == "recv": _append(log, item[1], "recv")
                    elif kind == "err":  _append(log, item[1], "err")
                    elif kind == "st":   st_var.set(item[1]); st_lbl.configure(fg=item[2])
                    elif kind == "enable_conn_btn":
                        self._conn_btn.configure(bg=A, fg=T)
                    elif kind == "__plog__":
                        _append(self._plog, item[1], item[2])
                except: pass
        self.after(120, self._poll)


# ── Bluetooth Section ──────────────────────────────────────────────────────

class BTSection(tk.Frame):
    DEVICES = [
        ("B8:27:EB:1A:2F:3C", "Raspberry Pi 4",  -65),
        ("A4:C3:F0:8E:5D:11", "Laptop Ubuntu",    -72),
        ("00:1A:7D:DA:71:13", "Android Phone",    -57),
        ("DC:A6:32:B1:9E:47", "ESP32-WROOM",      -80),
        ("F0:18:98:E3:B4:2A", "Arduino Nano 33",  -69),
    ]

    def __init__(self, master, app: App):
        super().__init__(master, bg=K)
        self.app = app
        self._connected = False
        self._key = None
        self._device = None
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/comms/bluetooth_rfcomm", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Bluetooth RFCOMM Secure Transfer. Pair via RSA-2048, Encrypt via AES-256-GCM.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Split pane
        split_frame = tk.Frame(main, bg=K)
        split_frame.pack(fill="both", expand=True, pady=5)
        split_frame.grid_columnconfigure(0, weight=1)
        split_frame.grid_columnconfigure(1, weight=1)
        split_frame.grid_rowconfigure(0, weight=1)

        # Left pane (Devices)
        lf = tk.Frame(split_frame, bg=C, highlightbackground=S, highlightthickness=1)
        lf.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        bar = tk.Frame(lf, bg=S, padx=10, pady=5); bar.pack(fill="x")
        tk.Label(bar, text="[ BLUETOOTH DEVICES ]", font=FBB, bg=S, fg=T).pack(side="left")
        self._scan_btn = _btn(bar, "SCAN_DEVICES", self._scan, accent=SEL)
        self._scan_btn.pack(side="right")
        self._devlist = tk.Listbox(lf, bg=K, fg=T, font=FM, bd=0, selectbackground=A, selectforeground=T, activestyle="none", height=10)
        self._devlist.pack(fill="both", expand=True, padx=10, pady=10)
        self._devlist.bind("<<ListboxSelect>>", self._on_select)
        self._pair_btn = _btn(lf, "PAIR_AND_CONNECT", self._pair, accent=MUT, fg=DIM)
        self._pair_btn.pack(fill="x", padx=10, pady=(0,10))

        # Right pane (Transfer)
        rf = tk.Frame(split_frame, bg=C, highlightbackground=S, highlightthickness=1)
        rf.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        bar2 = tk.Frame(rf, bg=S, padx=10, pady=5); bar2.pack(fill="x")
        tk.Label(bar2, text="[ RFCOMM ENCRYPTED TRANSFER ]", font=FBB, bg=S, fg=T).pack(side="left")
        self._bt_stlbl = tk.Label(bar2, text="[DISCONNECTED]", font=FBB, bg=S, fg=WRN)
        self._bt_stlbl.pack(side="right")
        self._bt_log = _log(rf, height=14)
        self._bt_log.pack(fill="both", expand=True, padx=10, pady=10)
        ir = tk.Frame(rf, bg=C, padx=10, pady=10); ir.pack(fill="x")
        self._bt_msg = tk.StringVar()
        e = _entry(ir, self._bt_msg); e.pack(side="left", fill="x", expand=True)
        sb = _btn(ir, "SEND", self._bt_send, accent=SEL)
        sb.pack(side="right", padx=(10,0))
        e.bind("<Return>", lambda _: self._bt_send())

    def _scan(self):
        self._devlist.delete(0, "end")
        self._scan_btn.configure(text="Scan…", state="disabled")
        def _do():
            time.sleep(1.0)
            for mac, name, rssi in self.DEVICES:
                self._devlist.insert("end", f"  {name:<22}  {rssi} dBm")
                time.sleep(0.1)
            self.after(0, lambda: self._scan_btn.configure(text="Scan 🔍", state="normal"))
            self.after(0, lambda: _append(self._bt_log,
                f"[{now()}] {len(self.DEVICES)} appareils trouvés.", "sys"))
        threading.Thread(target=_do, daemon=True).start()

    def _on_select(self, _):
        sel = self._devlist.curselection()
        if sel:
            self._device = self.DEVICES[sel[0]]
            self._pair_btn.configure(bg=A, fg=T)

    def _pair(self):
        if not self._device: return
        mac, name, rssi = self._device
        def _do():
            time.sleep(0.6)
            self.after(0, lambda: _append(self._bt_log,
                f"[{now()}] Connexion à {name} ({mac})…", "sys"))
            time.sleep(0.5)
            priv, pub = rsa_keygen(2048)
            if priv:
                self._key = secrets.token_bytes(32)
                enc_k = rsa_enc(self._key, pub)
                self.after(0, lambda: (
                    _append(self._bt_log, f"[{now()}] Clé AES chiffrée RSA ({len(enc_k)} B)", "crypto"),
                    _append(self._bt_log, f"  Clé : {self._key.hex()[:32]}…", "crypto")
                ))
            else:
                self._key = hashlib.sha256(b"bt_demo").digest()
            self._connected = True
            self.after(0, lambda: self._bt_stlbl.configure(text=f"● {name}", fg=OK))
            self.after(0, lambda: _append(self._bt_log, f"[{now()}] Canal RFCOMM sécurisé ✓", "recv"))
        threading.Thread(target=_do, daemon=True).start()

    def _bt_send(self):
        msg = self._bt_msg.get().strip()
        if not msg: return
        if not self._connected:
            messagebox.showwarning("Bluetooth", "Connectez-vous d'abord."); return
        ct, nonce, tag = aes_enc(msg.encode(), self._key)
        _append(self._bt_log, f"[{now()}] 🔒 Envoyé : «{msg}»", "sent")
        _append(self._bt_log, f"  nonce={nonce.hex()[:16]}…  ct={ct.hex()[:24]}…", "crypto")
        self._bt_msg.set("")
        def _sim():
            time.sleep(0.25)
            try:
                pt = aes_dec(ct, self._key, nonce, tag)
                self.after(0, lambda: _append(self._bt_log,
                    f"[{now()}] 📨 Reçu : «{pt.decode()}»", "recv"))
            except Exception as e:
                self.after(0, lambda e=e: _append(self._bt_log, f"Erreur : {e}", "err"))
        threading.Thread(target=_sim, daemon=True).start()


# ── UDP Chat Section ───────────────────────────────────────────────────────

class UDPSection(tk.Frame):
    USERS = [
        ("Nova",   UDP_PORT_BASE,     "#8b5cf6"),
        ("Orion",  UDP_PORT_BASE + 1, "#7c3aed"),
        ("Zephyr", UDP_PORT_BASE + 2, "#6d28d9"),
    ]

    def __init__(self, master, app: App):
        super().__init__(master, bg=K)
        self.app = app
        self._user_idx  = 0
        self._socks     = [None, None, None]
        self._running   = False
        self._group_key = hashlib.sha256(b"udp_group_key_demo").digest()
        self._mq: queue.Queue = queue.Queue()
        self._build()
        self._poll()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/comms/udp_chat", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: UDP Secure Chat (Group chat). Encrypted via AES-256-GCM using group key.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Split pane
        split_frame = tk.Frame(main, bg=K)
        split_frame.pack(fill="both", expand=True, pady=5)
        split_frame.grid_columnconfigure(0, weight=2)
        split_frame.grid_columnconfigure(1, weight=1)
        split_frame.grid_rowconfigure(0, weight=1)

        # Chat Pane
        cf = tk.Frame(split_frame, bg=C, highlightbackground=S, highlightthickness=1)
        cf.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        bar = tk.Frame(cf, bg=S, padx=10, pady=5); bar.pack(fill="x")
        tk.Label(bar, text="[ SECURE ROOM (AES-GCM) ]", font=FBB, bg=S, fg=T).pack(side="left")
        self._udp_st = tk.Label(bar, text="[OFFLINE]", font=FBB, bg=S, fg=WRN)
        self._udp_st.pack(side="right")
        
        tags = {u[0]: u[2] for u in self.USERS}
        tags.update({"sys": WRN, "info": G})
        self._chat = _log(cf, height=14, tags=tags)
        self._chat.pack(fill="both", expand=True, padx=10, pady=10)
        
        ir = tk.Frame(cf, bg=C, padx=10, pady=10); ir.pack(fill="x")
        self._umsg = tk.StringVar()
        e = _entry(ir, self._umsg); e.pack(side="left", fill="x", expand=True)
        _btn(ir, "SEND", self._udp_send, accent=SEL).pack(side="right", padx=(10, 0))
        e.bind("<Return>", lambda _: self._udp_send())

        # Participants Pane
        rp = tk.Frame(split_frame, bg=C, highlightbackground=S, highlightthickness=1)
        rp.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        bar2 = tk.Frame(rp, bg=S, padx=10, pady=5); bar2.pack(fill="x")
        tk.Label(bar2, text="[ PARTICIPANTS ]", font=FBB, bg=S, fg=T).pack(anchor="w")
        
        self._user_btns = []
        for i, (name, port, color) in enumerate(self.USERS):
            b = tk.Button(rp, text=f"[*] {name} (:{port})", anchor="w",
                          font=FBB, bg=C, fg=color, bd=0, relief="flat",
                          padx=15, pady=10, activebackground=D, cursor="hand2",
                          command=lambda idx=i: self._sel_user(idx))
            b.pack(fill="x"); self._user_btns.append(b)
            
        _sep(rp).pack(fill="x", padx=10, pady=10)
        self._net_btn = _btn(rp, "START_NETWORK", self._toggle_net, accent=SEL)
        self._net_btn.pack(fill="x", padx=15)
        
        _sep(rp).pack(fill="x", padx=10, pady=10)
        tk.Label(rp, text="--group_key", font=FS, bg=C, fg=DIM).pack(anchor="w", padx=15)
        k = self._group_key.hex()
        tk.Label(rp, text=k[:16]+"\n"+k[16:32], font=FM, bg=C, fg=G).pack(anchor="w", padx=15)
        
        _sep(rp).pack(fill="x", padx=10, pady=10)
        tk.Label(rp, text="--identity", font=FS, bg=C, fg=DIM).pack(anchor="w", padx=15)
        self._id_lbl = tk.Label(rp, text=self.USERS[0][0], font=FBB, bg=C, fg=self.USERS[0][2])
        self._id_lbl.pack(anchor="w", padx=15)
        self._sel_user(0)

    def _sel_user(self, idx):
        self._user_idx = idx
        n, _, c = self.USERS[idx]
        self._id_lbl.configure(text=n, fg=c)
        for i, b in enumerate(self._user_btns):
            b.configure(bg=D if i == idx else C)

    def _toggle_net(self):
        if not self._running:
            self._running = True
            self._net_btn.configure(text="Arrêter le réseau", bg=ERR)
            self._udp_st.configure(text="● En ligne", fg=OK)
            for i, (_, port, _) in enumerate(self.USERS):
                try:
                    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    s.bind(("127.0.0.1", port)); s.settimeout(0.3)
                    self._socks[i] = s
                    threading.Thread(target=self._recv, args=(i,), daemon=True).start()
                except Exception as e:
                    self._mq.put(("sys", f"Erreur port {port}: {e}"))
            self._mq.put(("sys", f"[{now()}] Réseau UDP — 3 participants"))
        else:
            self._running = False
            for i, s in enumerate(self._socks):
                if s:
                    try: s.close()
                    except: pass
                    self._socks[i] = None
            self._net_btn.configure(text="Démarrer le réseau", bg=A)
            self._udp_st.configure(text="○ Hors ligne", fg=WRN)

    def _recv(self, idx):
        s = self._socks[idx]
        while self._running and s:
            try:
                data, _ = s.recvfrom(8192)
                sender  = data[:16].rstrip(b"\x00").decode(errors="replace")
                nonce, tag, ct = data[16:32], data[32:48], data[48:]
                pt  = aes_dec(ct, self._group_key, nonce, tag)
                msg = pt.decode()
                color = next((u[2] for u in self.USERS if u[0] == sender), T)
                self._mq.put(("msg", sender, msg, color))
            except socket.timeout: continue
            except: continue

    def _udp_send(self):
        msg = self._umsg.get().strip()
        if not msg or not self._running: return
        name, my_port, color = self.USERS[self._user_idx]
        ct, nonce, tag = aes_enc(msg.encode(), self._group_key)
        frame = name.encode().ljust(16, b"\x00") + nonce + tag + ct
        for _, port, _ in self.USERS:
            # ← envoie à TOUS les ports y compris le sien
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.sendto(frame, ("127.0.0.1", port));
                s.close()
            except:
                pass
        # ← supprimer le self._mq.put() direct
        self._umsg.set("")

    def _poll(self):
        while not self._mq.empty():
            try:
                item = self._mq.get_nowait()
                if item[0] == "msg":
                    _, sender, msg, color = item
                    self._chat.configure(state="normal")
                    self._chat.insert("end", f"[{now()}] ", "sys")
                    self._chat.insert("end", f"{sender}: ", sender)
                    self._chat.insert("end", msg + "\n")
                    self._chat.see("end")
                    self._chat.configure(state="disabled")
                elif item[0] in ("sys", "info"):
                    _append(self._chat, item[1], item[0])
            except: pass
        self.after(120, self._poll)


# ── Vote Section ───────────────────────────────────────────────────────────

class VoteSection(tk.Frame):
    CANDIDATES = ["Alice Dupont", "Bob Martin", "Charlie Lambert"]
    VOTERS     = [f"Électeur {i}" for i in range(1, 7)]
    ICONS      = ["🟣", "🔵", "🟢"]

    def __init__(self, master, app: App):
        super().__init__(master, bg=K)
        self.app       = app
        self._paillier = None
        self._paillier_ok = False
        self._votes    = []
        self._tallies  = None
        self._results  = None
        self._build()

    def _build(self):
        main = tk.Frame(self, bg=K)
        main.pack(fill="both", expand=True, padx=40, pady=20)

        # Title
        tk.Label(main, text="> module/comms/homomorphic_vote", font=FBB, bg=K, fg=B).pack(anchor="w", pady=(0, 10))
        tk.Label(main, text="INFO: Secure E-Voting using Paillier Homomorphic Encryption. Votes are encrypted and tallied without decryption.", font=FS, bg=K, fg=DIM).pack(anchor="w", pady=(0, 15))

        # Split pane
        split_frame = tk.Frame(main, bg=K)
        split_frame.pack(fill="both", expand=True, pady=5)
        split_frame.grid_columnconfigure(0, weight=1)
        split_frame.grid_columnconfigure(1, weight=1)
        split_frame.grid_rowconfigure(0, weight=1)

        # Left pane (Voting Booth)
        lf = tk.Frame(split_frame, bg=C, highlightbackground=S, highlightthickness=1)
        lf.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        bar = tk.Frame(lf, bg=S, padx=10, pady=5); bar.pack(fill="x")
        tk.Label(bar, text="[ VOTING BOOTH ]", font=FBB, bg=S, fg=T).pack(side="left")

        vf = tk.Frame(lf, bg=C, padx=10, pady=10); vf.pack(fill="x")
        tk.Label(vf, text="--voter_id", font=FS, bg=C, fg=DIM).pack(anchor="w")
        self._voter_var = tk.StringVar(value=self.VOTERS[0])
        _combo(vf, self._voter_var, self.VOTERS, width=20).pack(anchor="w", pady=5)
        
        _sep(lf).pack(fill="x", padx=10)
        tk.Label(lf, text="--candidate", font=FBB, bg=C, fg=T, pady=10).pack(padx=10, anchor="w")
        self._vote_var = tk.IntVar(value=-1)
        for i, (c, ico) in enumerate(zip(self.CANDIDATES, self.ICONS)):
            tk.Radiobutton(lf, text=f" [{ico}] {c}", variable=self._vote_var,
                           value=i, font=FB, bg=C, fg=T, selectcolor=A,
                           activebackground=C, cursor="hand2", pady=5).pack(anchor="w", padx=20)
                           
        _sep(lf).pack(fill="x", padx=10, pady=10)
        
        ctrl_f = tk.Frame(lf, bg=C, padx=10, pady=10); ctrl_f.pack(fill="x")
        self._init_btn = _btn(ctrl_f, "INIT_PAILLIER_KEY", self._init_paillier, accent=SEL)
        self._init_btn.pack(fill="x", pady=2)
        self._vote_btn = _btn(ctrl_f, "CAST_ENCRYPTED_VOTE", self._cast, accent=SEL)
        self._vote_btn.configure(state="disabled")
        self._vote_btn.pack(fill="x", pady=2)
        self._p_lbl = tk.Label(ctrl_f, text="[PAILLIER_UNINITIALIZED]", font=FBB, bg=C, fg=ERR)
        self._p_lbl.pack(pady=5)

        # Right pane (Results)
        rf = tk.Frame(split_frame, bg=C, highlightbackground=S, highlightthickness=1)
        rf.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        bbar = tk.Frame(rf, bg=S, padx=10, pady=5); bbar.pack(fill="x")
        tk.Label(bbar, text="[ BALLOT BOX & RESULTS ]", font=FBB, bg=S, fg=T).pack(side="left")
        self._vote_ct = tk.Label(bbar, text="COUNT: 0", font=FBB, bg=S, fg=DIM)
        self._vote_ct.pack(side="right")
        
        self._vlog = _log(rf, height=10)
        self._vlog.pack(fill="both", expand=True, padx=10, pady=10)
        
        btnrow = tk.Frame(rf, bg=C, padx=10, pady=5); btnrow.pack(fill="x")
        _btn(btnrow, "TALLY_VOTES", self._tally, accent=SEL).pack(side="left", padx=2)
        _btn(btnrow, "DECRYPT_RESULTS", self._reveal, accent=SEL).pack(side="left", padx=2)
        _btn(btnrow, "RESET_ELECTION", self._reset, accent=ERR).pack(side="right", padx=2)
        
        bars_f = tk.Frame(rf, bg=C, padx=10, pady=10); bars_f.pack(fill="x")
        self._bars = []
        for c, ico in zip(self.CANDIDATES, self.ICONS):
            row = tk.Frame(bars_f, bg=C); row.pack(fill="x", pady=5)
            tk.Label(row, text=f"[{ico}] {c}", font=FB, bg=C, fg=T, width=20, anchor="w").pack(side="left")
            cv = tk.Canvas(row, bg=K, height=14, width=150, bd=0, highlightthickness=1, highlightbackground=S)
            cv.pack(side="left", padx=10)
            cv.create_rectangle(0, 0, 0, 14, fill=SEL, outline="", tags="bar")
            lbl = tk.Label(row, text="—", font=FBB, bg=C, fg=DIM, width=5)
            lbl.pack(side="left")
            self._bars.append((cv, lbl))

    def _init_paillier(self):
        if not _PAILLIER:
            self._p_lbl.configure(text="Simulation (sans Paillier)", fg=WRN)
            self._paillier_ok = True
            self._vote_btn.configure(bg=A, fg=T, state="normal")
            return
        self._init_btn.configure(text="Génération…", state="disabled")
        def _do():
            try:
                self._paillier = Paillier(bits=256)
                self.after(0, self._paillier_ready)
            except Exception as e:
                self.after(0, lambda: self._init_btn.configure(text="⚙ Réessayer", state="normal"))
        threading.Thread(target=_do, daemon=True).start()

    def _paillier_ready(self):
        self._paillier_ok = True
        self._init_btn.configure(text="✓ Paillier prêt", bg=OK, fg="#000", state="disabled")
        self._p_lbl.configure(text="Paillier 256-bit actif", fg=OK)
        self._vote_btn.configure(bg=A, fg=T, state="normal")
        _append(self._vlog, f"[{now()}] Paillier initialisé  n={hex(self._paillier.n)[:16]}…", "sys")

    def _cast(self):
        voter = self._voter_var.get()
        cand  = self._vote_var.get()
        if cand < 0: messagebox.showwarning("Vote", "Choisissez un candidat."); return
        if any(v["voter"] == voter for v in self._votes):
            messagebox.showwarning("Vote", f"{voter} a déjà voté."); return
        if not self._paillier_ok:
            messagebox.showwarning("Vote", "Initialisez Paillier d'abord."); return
        if self._paillier and _PAILLIER:
            enc = [self._paillier.encrypt(1 if i == cand else 0)
                   for i in range(len(self.CANDIDATES))]
        else:
            enc = [1 + int.from_bytes(secrets.token_bytes(8), "big") if i == cand
                   else int.from_bytes(hashlib.sha256(f"{voter}{i}".encode()).digest(), "big")
                   for i in range(len(self.CANDIDATES))]
        self._votes.append({"voter": voter, "cand": cand, "enc": enc})
        self._vote_ct.configure(text=f"{len(self._votes)} vote(s)")
        _append(self._vlog, f"[{now()}] ✓ {voter} — vote chiffré déposé", "vote")
        for i, e in enumerate(enc):
            _append(self._vlog, f"   Cand. {i+1}: {hex(e)[:16]}…", "tally")
        used = {v["voter"] for v in self._votes}
        for v in self.VOTERS:
            if v not in used: self._voter_var.set(v); break
        self._vote_var.set(-1)

    def _tally(self):
        if not self._votes: messagebox.showwarning("Dépouillement", "Aucun vote."); return
        _append(self._vlog, f"\n[{now()}] ══ Dépouillement homomorphe ══", "sys")
        if self._paillier and _PAILLIER:
            self._tallies = []
            for i in range(len(self.CANDIDATES)):
                acc = self._paillier.encrypt(0)
                for v in self._votes:
                    acc = self._paillier.add_ciphertexts(acc, v["enc"][i])
                self._tallies.append(acc)
                _append(self._vlog, f"   Cand. {i+1} total chiffré = {hex(acc)[:16]}…", "tally")
        else:
            self._tallies = [sum(1 for v in self._votes if v["cand"]==i)
                             for i in range(len(self.CANDIDATES))]
            for i, t in enumerate(self._tallies):
                _append(self._vlog, f"   Cand. {i+1} total simulé = {t}", "tally")
        _append(self._vlog, "   → Votes individuels restent chiffrés ✓", "sys")

    def _reveal(self):
        if self._tallies is None: messagebox.showwarning("Résultats", "Dépouillez d'abord."); return
        if self._paillier and _PAILLIER:
            self._results = [self._paillier.decrypt(t) for t in self._tallies]
        else:
            self._results = list(self._tallies)
        _append(self._vlog, f"\n[{now()}] ══ RÉSULTATS OFFICIELS ══", "result")
        mx    = max(self._results)
        total = sum(self._results) or 1
        for i, (c, ico, score) in enumerate(zip(self.CANDIDATES, self.ICONS, self._results)):
            crown = " 🏆" if score == mx and mx > 0 else ""
            _append(self._vlog, f"   {ico} {c:<20} {score} vote(s){crown}", "result")
            cv, lbl = self._bars[i]
            w = int((score / total) * 200)
            cv.coords("bar", 0, 0, max(w, 1), 14)
            lbl.configure(text=str(score), fg=OK)

    def _reset(self):
        self._votes.clear(); self._tallies = None; self._results = None
        self._vote_var.set(-1); self._voter_var.set(self.VOTERS[0])
        self._vote_ct.configure(text="0 vote(s)")
        _clear(self._vlog)
        for cv, lbl in self._bars:
            cv.coords("bar", 0, 0, 0, 14); lbl.configure(text="—", fg=DIM)


# ═══════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    app = App()
    app.mainloop()