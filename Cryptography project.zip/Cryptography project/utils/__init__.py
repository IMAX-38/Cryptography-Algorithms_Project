"""
utils/__init__.py
-----------------
Public API for the shared utilities package.
"""

from .math_utils import (
    gcd,
    extended_gcd,
    mod_inverse,
    fast_pow,
    is_coprime,
    lcm,
    euler_totient,
    carmichael_lambda,
)

from .primes import (
    is_prime_miller_rabin,
    generate_prime,
    generate_safe_prime,
    generate_prime_pair,
    find_primitive_root,
)

from .converter import (
    text_to_bytes,
    bytes_to_text,
    bytes_to_hex,
    hex_to_bytes,
    int_to_bytes,
    bytes_to_int,
    text_to_int,
    int_to_text,
    xor_bytes,
)

__all__ = [
    # math_utils
    "gcd", "extended_gcd", "mod_inverse", "fast_pow",
    "is_coprime", "lcm", "euler_totient", "carmichael_lambda",
    # primes
    "is_prime_miller_rabin", "generate_prime", "generate_safe_prime",
    "generate_prime_pair", "find_primitive_root",
    # converter
    "text_to_bytes", "bytes_to_text", "bytes_to_hex", "hex_to_bytes",
    "int_to_bytes", "bytes_to_int", "text_to_int", "int_to_text", "xor_bytes",
]
