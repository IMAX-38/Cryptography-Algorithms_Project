"""
main.py
-------
CryptoLab Interactive CLI

An interactive command-line interface covering classical, symmetric,
asymmetric, hashing, signature, and homomorphic encryption demonstrations.
"""

import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

# ─────────────────────────────────────────────────────────────────────────────
MENU = """
╔═══════════════════════════════════════════════════════════════╗
║               🔐 CRYPTOLAB — COMPLETE SUITE                   ║
╠═══════════════════════════════════════════════════════════════╣
║  MODULE 1 — CLASSICAL CIPHERS                                 ║
║    1.  Caesar Cipher  (brute-force + IC analysis)             ║
║    2.  Hill Cipher    (2×2 / 3×3 + known-plaintext attack)    ║
║    3.  Playfair Cipher                                        ║
║    4.  Vigenère Cipher (Kasiski + IC cryptanalysis)           ║
║    5.  One-Time Pad   (key-reuse vulnerability + crib drag)   ║
║    6.  Frequency Analysis + Index of Coincidence              ║
║                                                               ║
║  MODULE 2 — SYMMETRIC CIPHERS                                 ║
║    7.  RC4 Stream Cipher  (deprecated)                        ║
║    8.  AES (128 / 192 / 256-bit, ECB / CBC / CTR / GCM)      ║
║    9.  DES / Triple-DES                                       ║
║                                                               ║
║  MODULE 3 — ASYMMETRIC CRYPTOGRAPHY                           ║
║   10.  RSA  (2048-bit, OAEP)                                  ║
║   11.  Diffie-Hellman Key Exchange  (+ MITM simulation)       ║
║   12.  ElGamal Encryption                                     ║
║   13.  Shamir's Secret Sharing                                ║
║                                                               ║
║  MODULE 4 — HASH FUNCTIONS                                    ║
║   14.  MD5 / SHA-1 / SHA-256 / SHA-512 / SHA-3               ║
║   15.  HMAC-SHA256                                            ║
║                                                               ║
║  MODULE 5 — DIGITAL SIGNATURES                                ║
║   16.  RSA-PSS / ECDSA / EdDSA                               ║
║                                                               ║
║  MODULE 6 — PROTOCOLS                                         ║
║   17.  Homomorphic Encryption  (Paillier)                     ║
║                                                               ║
║    0.  Exit                                                   ║
╚═══════════════════════════════════════════════════════════════╝
"""


def section_header(title: str = "") -> None:
    """Print a decorative section separator."""
    width = 63
    if title:
        print(f"\n{'─' * 4} {title} {'─' * (width - len(title) - 6)}")
    else:
        print("─" * width)


def prompt_input(label: str, default=None):
    """Prompt the user for input, returning *default* if they press Enter."""
    value = input(f"  {label}: ").strip()
    return value if value else default


# ══════════════════════════════════════════════════════════════════════════════
# MODULE 1 — CLASSICAL
# ══════════════════════════════════════════════════════════════════════════════

def demo_caesar():
    section_header("CAESAR CIPHER")
    from caesar import (encrypt_caesar, decrypt_caesar,
                        print_analysis, brute_force_caesar)
    print("  [1] Encrypt/Decrypt   [2] Brute-force   [3] IC Analysis")
    choice = prompt_input("Choice", "1")

    if choice == "1":
        msg   = prompt_input("Plaintext", "Hello world")
        shift = int(prompt_input("Shift k", "7"))
        enc   = encrypt_caesar(msg, shift)
        dec   = decrypt_caesar(enc, shift)
        print(f"\n  Ciphertext : {enc}")
        print(f"  Decrypted  : {dec}")

    elif choice == "2":
        ct = prompt_input("Ciphertext", encrypt_caesar("Vive la cryptographie", 11))
        candidates = brute_force_caesar(ct, top_n=5)
        print("\n  ── Brute-force (top 5) ──")
        for k, score, text in candidates:
            print(f"  k={k:2d}  score={score:.3f}  →  {text[:60]}")

    elif choice == "3":
        msg   = prompt_input("Message to encrypt (key hidden)", "les sciences sont belles")
        shift = int(prompt_input("Secret key k", "9"))
        ct    = encrypt_caesar(msg, shift)
        print(f"\n  Ciphertext : {ct}")
        print_analysis(ct)


def demo_hill():
    section_header("HILL CIPHER")
    from hill import (encrypt_hill, decrypt_hill, validate_key,
                      demo_known_plaintext_attack, DEMO_KEY_2X2)
    print("  [1] Encrypt/Decrypt 2×2   [2] Known-plaintext attack")
    choice = prompt_input("Choice", "1")

    if choice == "1":
        msg = prompt_input("Plaintext", "CRYPTOGRAPHY")
        print(f"  Key used (2×2) : {DEMO_KEY_2X2}")
        valid, vmsg = validate_key(DEMO_KEY_2X2)
        print(f"  Key valid      : {'✓' if valid else '✗'} {vmsg}")
        enc = encrypt_hill(msg, DEMO_KEY_2X2)
        dec = decrypt_hill(enc, DEMO_KEY_2X2)
        print(f"\n  Ciphertext : {enc}")
        print(f"  Decrypted  : {dec}")

    elif choice == "2":
        print("\n  Known-plaintext attack on DEMO_KEY_2X2:")
        demo_known_plaintext_attack(DEMO_KEY_2X2)


def demo_playfair():
    section_header("PLAYFAIR CIPHER")
    from playfair import encrypt, decrypt
    key = prompt_input("Keyword", "MONARCHY")
    msg = prompt_input("Plaintext", "INSTRUMENTS")
    enc = encrypt(msg, key)
    dec = decrypt(enc, key)
    print(f"\n  Ciphertext : {enc}")
    print(f"  Decrypted  : {dec}")


def demo_vigenere():
    section_header("VIGENÈRE CIPHER")
    from vigenere import (encrypt_vigenere, decrypt_vigenere,
                          print_cryptanalysis)
    print("  [1] Encrypt/Decrypt   [2] Full cryptanalysis")
    choice = prompt_input("Choice", "1")

    if choice == "1":
        key = prompt_input("Key", "LEMON")
        msg = prompt_input("Plaintext", "ATTACKATDAWN")
        enc = encrypt_vigenere(msg, key)
        dec = decrypt_vigenere(enc, key)
        print(f"\n  Ciphertext : {enc}")
        print(f"  Decrypted  : {dec}")

    elif choice == "2":
        key = prompt_input("Secret key (to generate the example)", "SECRET")
        msg = prompt_input("Message (will be repeated 4× for Kasiski)",
                           "les mathematiques sont le langage universel")
        ct  = encrypt_vigenere(msg * 4, key)
        print(f"\n  Ciphertext (excerpt) : {ct[:80]}...")
        print_cryptanalysis(ct)


def demo_otp():
    section_header("ONE-TIME PAD")
    from otp import (encrypt_text, decrypt_text,
                     demo_key_reuse, crib_dragging, demo_full)
    print("  [1] Encrypt/Decrypt   [2] Key-reuse vulnerability   [3] Full demo")
    choice = prompt_input("Choice", "1")

    if choice == "1":
        msg    = prompt_input("Secret message", "Top secret message")
        ct, key = encrypt_text(msg)
        dec    = decrypt_text(ct, key)
        print(f"\n  Key (hex)  : {key.hex()}")
        print(f"  Ciphertext : {ct.hex()}")
        print(f"  Decrypted  : {dec}")
        print(f"  Correct    : {dec == msg} ✓")
        print(f"\n  ⚠ One-time use only — NEVER reuse this key!")

    elif choice == "2":
        m1  = prompt_input("Message 1", "The password is ALPHA")
        m2  = prompt_input("Message 2", "Meet at midnight here")
        res = demo_key_reuse(m1, m2)
        print(f"\n  C1 XOR C2 = M1 XOR M2 : {res['xor_c1_c2_hex'][:48]}...")
        print(f"  Equal to M1 XOR M2    : {res['xor_equal']} ← key cancelled out!")
        print(f"\n  {res['explanation']}")
        xor = res['_xor']
        print(f"\n  Crib-dragging with 'The ':")
        for h in crib_dragging(xor, "The ", score_threshold=1.0)[:3]:
            print(f"    pos={h['position']:3d}  fragment='{h['fragment_m2']}'  "
                  f"score={h['score']}")

    elif choice == "3":
        demo_full()


def demo_frequency_analysis():
    section_header("FREQUENCY ANALYSIS")
    from frequency import print_frequency_analysis, index_of_coincidence
    msg = prompt_input("Text to analyse", "THEQUICKBROWNFOXJUMPSOVERTHELAZYDOG")
    print_frequency_analysis(msg)


# ══════════════════════════════════════════════════════════════════════════════
# MODULE 2 — SYMMETRIC
# ══════════════════════════════════════════════════════════════════════════════

def demo_rc4():
    section_header("RC4 STREAM CIPHER")
    from rc4 import encrypt_text, decrypt_text
    key = prompt_input("Key", "SecretKey")
    msg = prompt_input("Plaintext", "Hello, RC4!")
    ct  = encrypt_text(msg, key)
    dec = decrypt_text(ct, key)
    print(f"\n  Ciphertext (hex) : {ct.hex()}")
    print(f"  Decrypted        : {dec}")
    print(f"  ⚠ RC4 is deprecated. Use AES-GCM in production.")


def demo_aes():
    section_header("AES 256-bit")
    from aes_cipher import encrypt_text, decrypt_text
    msg    = prompt_input("Plaintext", "Confidential AES-256 message!")
    mode   = prompt_input("Mode (GCM/CBC/CTR)", "GCM").upper()
    params = encrypt_text(msg, mode=mode)
    dec    = decrypt_text(params)
    print(f"\n  Key (hex) : {params['key'].hex()}")
    print(f"  CT  (hex) : {params['ciphertext'].hex()}")
    print(f"  Decrypted : {dec}")


def demo_des():
    section_header("DES / 3DES")
    from des_cipher import encrypt_text, decrypt_text
    msg      = prompt_input("Plaintext", "DES example message")
    use_3des = prompt_input("Use 3DES? (y/n)", "y").lower() == "y"
    params   = encrypt_text(msg, use_3des=use_3des)
    dec      = decrypt_text(params)
    print(f"\n  Algorithm : {params['algorithm']}")
    print(f"  Key (hex) : {params['key'].hex()}")
    print(f"  CT  (hex) : {params['ciphertext'].hex()}")
    print(f"  Decrypted : {dec}")


# ══════════════════════════════════════════════════════════════════════════════
# MODULE 3 — ASYMMETRIC
# ══════════════════════════════════════════════════════════════════════════════

def demo_rsa():
    section_header("RSA 2048-bit")
    from rsa_cipher import generate_keypair, encrypt_oaep, decrypt_oaep
    print("  Generating 2048-bit RSA key pair...")
    priv, pub = generate_keypair(2048)
    msg = prompt_input("Plaintext", "Secret RSA message")
    ct  = encrypt_oaep(msg.encode(), pub)
    pt  = decrypt_oaep(ct, priv).decode()
    print(f"\n  CT  (hex) : {ct.hex()[:64]}...")
    print(f"  Decrypted : {pt}")


def demo_dh():
    section_header("DIFFIE-HELLMAN KEY EXCHANGE")
    from diffie_hellman import DHParty
    print("  Simulating Alice ↔ Bob (MODP 2048-bit group)...")
    alice     = DHParty()
    bob       = DHParty(p=alice.p, g=alice.g)
    key_alice = alice.derive_aes_key(bob.public_key)
    key_bob   = bob.derive_aes_key(alice.public_key)
    print(f"\n  Alice AES key : {key_alice.hex()}")
    print(f"  Bob   AES key : {key_bob.hex()}")
    print(f"  Match         : {key_alice == key_bob} ✓")


def demo_elgamal():
    section_header("ELGAMAL ENCRYPTION")
    from elgamal import ElGamal
    eg  = ElGamal(bits=256)
    msg = prompt_input("Plaintext", "ElGamal message")
    ct, length = eg.encrypt_text(msg)
    dec = eg.decrypt_text(ct, length)
    print(f"\n  Decrypted : {dec}")


def demo_shamir():
    section_header("SHAMIR'S SECRET SHARING")
    from shamir import split_text, reconstruct_text
    secret = prompt_input("Secret", "MySecretPassword!")
    n      = int(prompt_input("Total shares (n)", "5"))
    k      = int(prompt_input("Threshold (k)", "3"))
    shares, prime, byte_len = split_text(secret, n=n, k=k)
    print(f"\n  {n} shares generated. Reconstructing with shares 1, 3, {n}:")
    subset    = [shares[0], shares[2], shares[n - 1]]
    recovered = reconstruct_text(subset, prime, byte_len)
    print(f"  Recovered : {recovered}")
    print(f"  Correct   : {recovered == secret} ✓")


# ══════════════════════════════════════════════════════════════════════════════
# MODULE 4 — HASHING
# ══════════════════════════════════════════════════════════════════════════════

def demo_hashing():
    section_header("HASH FUNCTIONS")
    from sha_hash import hash_all
    msg     = prompt_input("Message to hash", "Hello, World!")
    digests = hash_all(msg)
    print()
    for algo, digest in digests.items():
        print(f"  {algo:<10}: {digest}")


def demo_hmac():
    section_header("HMAC-SHA256")
    from hmac_sign import generate_hmac_key, hmac_sha256, hmac_verify
    key   = generate_hmac_key()
    msg   = prompt_input("Message", "Authenticate this message")
    mac   = hmac_sha256(key, msg)
    valid = hmac_verify(key, msg, mac)
    print(f"\n  Key (hex) : {key.hex()}")
    print(f"  MAC       : {mac}")
    print(f"  Valid     : {valid} ✓")


# ══════════════════════════════════════════════════════════════════════════════
# MODULE 5 — DIGITAL SIGNATURES
# ══════════════════════════════════════════════════════════════════════════════

def demo_signatures():
    section_header("DIGITAL SIGNATURES")
    from signature import RSASignature, ECDSASignature
    msg = prompt_input("Message to sign", "Sign this important document")

    print("\n  RSA-PSS (2048-bit):")
    rsa = RSASignature(2048)
    sig = rsa.sign(msg)
    print(f"  Valid   : {RSASignature.verify(msg, sig, rsa.public_key)} ✓")
    print(f"  Tampered: {RSASignature.verify(msg + 'X', sig, rsa.public_key)} ✗")

    print("\n  ECDSA (P-256):")
    ec  = ECDSASignature("P-256")
    sig = ec.sign(msg)
    print(f"  Valid   : {ECDSASignature.verify(msg, sig, ec.public_key)} ✓")


# ══════════════════════════════════════════════════════════════════════════════
# MODULE 6 — PROTOCOLS
# ══════════════════════════════════════════════════════════════════════════════

def demo_homomorphic():
    section_header("HOMOMORPHIC ENCRYPTION — PAILLIER")
    from homomorphic import Paillier
    p = Paillier(bits=256)
    a = int(prompt_input("Value a", "42"))
    b = int(prompt_input("Value b", "17"))
    ca     = p.encrypt(a)
    cb     = p.encrypt(b)
    c_sum  = p.add_ciphertexts(ca, cb)
    c_diff = p.subtract_ciphertexts(ca, cb)
    k      = 5
    c_mul  = p.multiply_by_scalar(ca, k)
    print(f"\n  Enc({a}) + Enc({b}) decrypted : {p.decrypt(c_sum)}  (expected {a + b})")
    print(f"  Enc({a}) - Enc({b}) decrypted : {p.decrypt(c_diff)}  (expected {a - b})")
    print(f"  Enc({a}) × {k}       decrypted : {p.decrypt(c_mul)}  (expected {a * k})")


# ══════════════════════════════════════════════════════════════════════════════
# DISPATCH TABLE
# ══════════════════════════════════════════════════════════════════════════════

HANDLERS = {
    "1":  demo_caesar,
    "2":  demo_hill,
    "3":  demo_playfair,
    "4":  demo_vigenere,
    "5":  demo_otp,
    "6":  demo_frequency_analysis,
    "7":  demo_rc4,
    "8":  demo_aes,
    "9":  demo_des,
    "10": demo_rsa,
    "11": demo_dh,
    "12": demo_elgamal,
    "13": demo_shamir,
    "14": demo_hashing,
    "15": demo_hmac,
    "16": demo_signatures,
    "17": demo_homomorphic,
}


def main():
    print(MENU)
    while True:
        choice = input("\n  Select [0-17]: ").strip()
        if choice == "0":
            print("  Goodbye! 🔐")
            break
        handler = HANDLERS.get(choice)
        if handler:
            try:
                handler()
            except Exception as exc:
                print(f"\n  ❌ Error: {exc}")
                import traceback
                traceback.print_exc()
        else:
            print("  Invalid choice. Enter a number between 0 and 17.")


if __name__ == "__main__":
    main()
