"""
hashing/__init__.py
-------------------
Public API for the hashing package.
"""

from .sha_hash import (
    md5,
    sha1,
    sha256,
    sha512,
    sha3_256,
    sha3_512,
    hash_all,
    hash_file,
    verify_file_sha256,
    avalanche_effect,
    benchmark_throughput,
    compare_algorithms,
)

from .sha256_pure import (
    sha256_digest,
    sha256_hex,
    validate_against_hashlib,
    simulate_integrity_check,
)

__all__ = [
    "md5", "sha1", "sha256", "sha512", "sha3_256", "sha3_512",
    "hash_all", "hash_file", "verify_file_sha256",
    "avalanche_effect", "benchmark_throughput", "compare_algorithms",
    "sha256_digest", "sha256_hex",
    "validate_against_hashlib", "simulate_integrity_check",
]
