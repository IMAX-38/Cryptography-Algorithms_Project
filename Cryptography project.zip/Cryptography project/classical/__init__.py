"""
classical/__init__.py
---------------------
Public API for the classical ciphers package.
"""

from .caesar import (
    encrypt_caesar,
    decrypt_caesar,
    brute_force_caesar,
    detect_key_caesar,
    index_of_coincidence,
    deduce_key_by_frequency,
    full_analysis_caesar,
    print_analysis,
    FRENCH_LETTER_FREQUENCIES,
    IC_FRENCH,
)

from .vigenere import (
    encrypt_vigenere,
    decrypt_vigenere,
    kasiski_test,
    ic_by_key_length,
    recover_key,
    cryptanalyze_vigenere,
    print_cryptanalysis,
)

from .hill import (
    encrypt_hill,
    decrypt_hill,
    validate_key,
    known_plaintext_attack,
    demo_known_plaintext_attack,
    DEMO_KEY_2X2,
    DEMO_KEY_3X3,
)

from .otp import (
    generate_key,
    encrypt_otp,
    decrypt_otp,
    encrypt_text,
    decrypt_text,
    demo_key_reuse,
    crib_dragging,
    xor_space_analysis,
    demo_full,
)

__all__ = [
    # Caesar
    "encrypt_caesar", "decrypt_caesar", "brute_force_caesar",
    "detect_key_caesar", "index_of_coincidence", "deduce_key_by_frequency",
    "full_analysis_caesar", "print_analysis",
    "FRENCH_LETTER_FREQUENCIES", "IC_FRENCH",
    # Vigenere
    "encrypt_vigenere", "decrypt_vigenere", "kasiski_test",
    "ic_by_key_length", "recover_key", "cryptanalyze_vigenere",
    "print_cryptanalysis",
    # Hill
    "encrypt_hill", "decrypt_hill", "validate_key",
    "known_plaintext_attack", "demo_known_plaintext_attack",
    "DEMO_KEY_2X2", "DEMO_KEY_3X3",
    # OTP
    "generate_key", "encrypt_otp", "decrypt_otp",
    "encrypt_text", "decrypt_text", "demo_key_reuse",
    "crib_dragging", "xor_space_analysis", "demo_full",
]
