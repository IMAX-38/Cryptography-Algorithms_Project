"""
classical/otp.py
----------------
One-Time Pad (Vernam Cipher) — information-theoretically secure encryption.

Provides:
  1. generate_key / encrypt_otp / decrypt_otp — correct OTP implementation.
  2. Key-reuse vulnerability demo: C1 XOR C2 = M1 XOR M2 (key cancels out).
  3. Crib-dragging attack — partial plaintext recovery from C1 XOR C2.
  4. Space/letter XOR statistical analysis — locating spaces in ciphertext.

Security note:
  OTP provides perfect secrecy ONLY when:
    - The key is truly random (CSPRNG or hardware RNG).
    - The key is at least as long as the message.
    - Each key is used exactly ONCE and then destroyed.
  Any deviation from these rules breaks the security guarantee completely.
"""

import os
import secrets
from collections import Counter

# Characters scored highly during crib-dragging (common ASCII text bytes)
COMMON_CHARACTERS: frozenset[str] = frozenset(
    'etaoinshrdlucmfywgpbvkxjqzEASINTRULODMPCFBGHJKVXYQWZ '
)


# ── 1. OTP Implementation ──────────────────────────────────────────────────────

def generate_key(length: int) -> bytes:
    """Generate a cryptographically secure random key of *length* bytes."""
    return secrets.token_bytes(length)


def encrypt_otp(message: bytes, key: bytes) -> bytes:
    """
    OTP encryption: C = M XOR K.

    The key MUST be at least as long as the message.

    Raises:
        ValueError: If the key is shorter than the message.
    """
    if len(key) < len(message):
        raise ValueError(
            f"Key ({len(key)} bytes) must be >= message ({len(message)} bytes). "
            "A reused or short key breaks perfect secrecy."
        )
    return bytes(m ^ k for m, k in zip(message, key))


def decrypt_otp(ciphertext: bytes, key: bytes) -> bytes:
    """OTP decryption: M = C XOR K  (XOR is its own inverse)."""
    return encrypt_otp(ciphertext, key)


def encrypt_text(text: str, key: bytes = None) -> tuple[bytes, bytes]:
    """
    Encrypt a UTF-8 string.  Auto-generates a key if none is provided.

    Returns:
        *(ciphertext, key)* tuple.
    """
    data = text.encode('utf-8')
    if key is None:
        key = generate_key(len(data))
    return encrypt_otp(data, key), key


def decrypt_text(ciphertext: bytes, key: bytes) -> str:
    """Decrypt ciphertext bytes to a UTF-8 string."""
    return decrypt_otp(ciphertext, key).decode('utf-8', errors='replace')


# ── 2. Key-reuse vulnerability ────────────────────────────────────────────────

def demo_key_reuse(message1: str, message2: str) -> dict:
    """
    Demonstrate the catastrophic failure of OTP when a key is reused.

    If  C1 = M1 XOR K  and  C2 = M2 XOR K,
    then  C1 XOR C2 = M1 XOR M2  — the key vanishes completely.

    An attacker with C1 and C2 can compute M1 XOR M2 without ever knowing K.

    Returns:
        A dictionary with all intermediate values and an explanation.
        The ``_xor`` key holds the raw M1 XOR M2 bytes for further attacks.
    """
    m1 = message1.encode('utf-8')
    m2 = message2.encode('utf-8')
    length = min(len(m1), len(m2))
    m1, m2 = m1[:length], m2[:length]

    # FATAL: same key for both messages
    key = generate_key(length)
    c1 = encrypt_otp(m1, key)
    c2 = encrypt_otp(m2, key)

    xor_ciphertexts = bytes(a ^ b for a, b in zip(c1, c2))
    xor_plaintexts  = bytes(a ^ b for a, b in zip(m1, m2))
    identical       = xor_ciphertexts == xor_plaintexts

    return {
        'message1': message1[:length],
        'message2': message2[:length],
        'length': length,
        'c1_hex': c1.hex(),
        'c2_hex': c2.hex(),
        'xor_c1_c2_hex': xor_ciphertexts.hex(),
        'xor_m1_m2_hex': xor_plaintexts.hex(),
        'xor_equal': identical,
        'explanation': (
            "C1 XOR C2 = (M1 XOR K) XOR (M2 XOR K) = M1 XOR M2\n"
            "The attacker obtains M1 XOR M2 without knowing K."
        ),
        '_xor': xor_ciphertexts,
        '_m1_bytes': m1,
        '_m2_bytes': m2,
    }


# ── 3. Crib-dragging attack ───────────────────────────────────────────────────

def _xor_bytes(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))


def _is_printable(data: bytes, threshold: float = 0.85) -> bool:
    """Return True if >= threshold fraction of bytes are printable ASCII."""
    if not data:
        return False
    printable = sum(1 for b in data if 0x20 <= b <= 0x7E or b in (0x09, 0x0A, 0x0D))
    return printable / len(data) >= threshold


def _text_score(data: bytes) -> float:
    """
    Score how 'text-like' a byte sequence is.

    Higher weight for common vowels and English/French letters.
    """
    if not data:
        return 0.0
    score = sum(
        3 if chr(b) in 'eEaAiIoOuUsSntNT '
        else 2 if chr(b).isalpha()
        else 1 if chr(b).isprintable()
        else -1
        for b in data
    )
    return score / len(data)


def crib_dragging(
    xor_m1_m2: bytes,
    crib: str,
    score_threshold: float = 1.5,
) -> list[dict]:
    """
    Crib-dragging attack on M1 XOR M2.

    If we guess that M1 contains *crib* at position i, then:
        M2[i : i+|crib|] = XOR[i : i+|crib|] XOR crib

    Positions where the recovered M2 fragment looks like readable text
    are reported as probable hits.

    Args:
        xor_m1_m2:       The byte string C1 XOR C2 = M1 XOR M2.
        crib:            The guessed word/phrase to slide across the XOR.
        score_threshold: Minimum readability score to report a hit.

    Returns:
        List of ``{position, fragment_m2, score, crib_in}`` dicts, best first.
    """
    crib_bytes = crib.encode('utf-8')
    n_crib = len(crib_bytes)
    results = []

    for i in range(len(xor_m1_m2) - n_crib + 1):
        segment = xor_m1_m2[i:i + n_crib]
        candidate = _xor_bytes(segment, crib_bytes)
        score = _text_score(candidate)
        if score >= score_threshold and _is_printable(candidate):
            results.append({
                'position': i,
                'fragment_m2': candidate.decode('utf-8', errors='replace'),
                'score': round(score, 3),
                'crib_in': f"M1[{i}:{i + n_crib}] | M2[{i}:{i + n_crib}]",
            })

    results.sort(key=lambda x: x['score'], reverse=True)
    return results


def xor_space_analysis(xor_m1_m2: bytes) -> dict:
    """
    Statistical XOR analysis to locate probable space characters.

    Key insight: letter XOR space = same letter in opposite case.
    So if XOR[i] is a letter, one of the two messages likely has a space at position i.

    Returns:
        A dictionary with probable space positions and an explanation.
    """
    probable_spaces = []
    for i, b in enumerate(xor_m1_m2):
        if 0x41 <= b <= 0x5A or 0x61 <= b <= 0x7A:
            probable_spaces.append({
                'position': i,
                'xor_byte': b,
                'xor_char': chr(b),
                'interpretation': (
                    f"M1[{i}]=' ', M2[{i}]='{chr(b)}'"
                    f"  OR  M1[{i}]='{chr(b)}', M2[{i}]=' '"
                ),
            })
    return {
        'xor_length': len(xor_m1_m2),
        'probable_space_positions': probable_spaces[:20],
        'num_positions': len(probable_spaces),
        'explanation': (
            "letter XOR space = same letter in opposite case.\n"
            "If XOR[i] is a letter, one of the messages has a space at position i."
        ),
    }


# ── Full demonstration ────────────────────────────────────────────────────────

def demo_full() -> None:
    """Print a complete OTP demonstration covering all four aspects."""
    print("=" * 65)
    print("  ONE-TIME PAD — COMPLETE DEMONSTRATION")
    print("=" * 65)

    print("\n  ── 1. Correct usage ──")
    msg = "Top secret message"
    ct, key = encrypt_text(msg)
    dec = decrypt_text(ct, key)
    print(f"  Message   : {msg}")
    print(f"  Key (hex) : {key.hex()}")
    print(f"  Encrypted : {ct.hex()}")
    print(f"  Decrypted : {dec}")
    print(f"  Correct   : {dec == msg} ✓")

    print("\n  ── 2. Key-reuse vulnerability ──")
    m1 = "The password is ALPHA"
    m2 = "Meet at midnight here"
    res = demo_key_reuse(m1, m2)
    print(f"  M1         : {res['message1']}")
    print(f"  M2         : {res['message2']}")
    print(f"  C1 XOR C2  : {res['xor_c1_c2_hex'][:48]}...")
    print(f"  M1 XOR M2  : {res['xor_m1_m2_hex'][:48]}...")
    print(f"  Equal      : {res['xor_equal']} ← key has vanished!")
    print(f"\n  {res['explanation']}")

    print("\n  ── 3. Crib-dragging attack ──")
    xor = res['_xor']
    for crib in ["password", "Meet", "midnight", "The "]:
        hits = crib_dragging(xor, crib, score_threshold=1.2)
        if hits:
            print(f"\n  Crib '{crib}' → {len(hits)} hit(s):")
            for h in hits[:3]:
                print(f"    pos={h['position']:3d}  fragment='{h['fragment_m2']}'  "
                      f"score={h['score']}  ({h['crib_in']})")

    print("\n  ── 4. Space statistical analysis ──")
    stats = xor_space_analysis(xor)
    print(f"  {stats['num_positions']} positions with probable spaces detected.")
    for p in stats['probable_space_positions'][:5]:
        print(f"    {p['interpretation']}")

    print("\n" + "=" * 65)
    print("  OTP PRACTICAL CONSTRAINTS:")
    print("  1. Key distribution is as hard as distributing the message itself.")
    print("  2. Key generation must be truly random (not pseudo-random).")
    print("  3. Key must be securely destroyed after a single use.")
    print("  4. Sender and receiver must stay in sync.")
    print("  5. One key use only — reuse destroys all security.")
    print("=" * 65)


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    demo_full()
