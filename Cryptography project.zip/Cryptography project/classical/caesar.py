"""
classical/caesar.py
-------------------
Caesar Cipher — classical monoalphabetic substitution.

Provides:
  1. Encryption / decryption with an arbitrary integer shift k.
  2. Brute-force attack (all 26 shifts) with French-language scoring.
  3. Frequency-analysis key-deduction (chi-squared method) — no brute force required.

Security note:
  The key space is only 26.  A Caesar cipher is trivially broken by exhaustive
  search or simple frequency analysis and must never be used for real data.
"""

from collections import Counter
import math

# ── French letter frequencies (%) ─────────────────────────────────────────────
FRENCH_LETTER_FREQUENCIES: dict[str, float] = {
    'A': 7.636, 'B': 0.901, 'C': 3.260, 'D': 3.669, 'E': 14.715,
    'F': 1.066, 'G': 1.054, 'H': 1.069, 'I': 7.529, 'J': 0.545,
    'K': 0.049, 'L': 5.456, 'M': 2.968, 'N': 7.095, 'O': 5.378,
    'P': 3.021, 'Q': 0.836, 'R': 6.553, 'S': 7.948, 'T': 7.244,
    'U': 6.311, 'V': 1.628, 'W': 0.114, 'X': 0.427, 'Y': 0.128,
    'Z': 0.326,
}

# Theoretical Index of Coincidence:  French ≈ 0.074 | English ≈ 0.065 | random ≈ 0.038
IC_FRENCH: float = 0.074

# Common French words used for automatic language detection during brute-force
FRENCH_COMMON_WORDS: frozenset[str] = frozenset({
    'le', 'la', 'les', 'de', 'du', 'des', 'un', 'une', 'et', 'est',
    'en', 'que', 'qui', 'il', 'elle', 'nous', 'vous', 'ils', 'elles',
    'je', 'tu', 'on', 'par', 'sur', 'dans', 'avec', 'pour', 'pas',
    'ne', 'ce', 'se', 'sa', 'son', 'ses', 'mon', 'ma', 'mes', 'ton',
    'ta', 'tes', 'au', 'aux', 'ou', 'si', 'car', 'donc', 'mais', 'ni',
    'leur', 'leurs', 'tout', 'tous', 'bien', 'plus', 'tres', 'avoir',
    'etre', 'faire', 'dire', 'aller', 'voir', 'vouloir', 'pouvoir',
    'comme', 'quand', 'aussi', 'alors', 'encore', 'apres', 'avant',
    'sans', 'sous', 'entre', 'vers', 'chez', 'lors',
})


# ── 1. Encryption / Decryption ────────────────────────────────────────────────

def encrypt_caesar(text: str, shift: int) -> str:
    """
    Encrypt *text* with the Caesar cipher using the given *shift* k.

    Non-alphabetic characters are preserved as-is.
    The result is always uppercase.

    Args:
        text:  Plaintext string (any case).
        shift: Integer shift k (any value; reduced mod 26 internally).

    Returns:
        Uppercase ciphertext string.
    """
    shift = shift % 26
    result = []
    for char in text.upper():
        if char.isalpha():
            result.append(chr((ord(char) - ord('A') + shift) % 26 + ord('A')))
        else:
            result.append(char)
    return ''.join(result)


def decrypt_caesar(text: str, shift: int) -> str:
    """
    Decrypt a Caesar-ciphered *text* using the given *shift* k.

    This is simply ``encrypt_caesar(text, -shift)``.
    """
    return encrypt_caesar(text, -shift)


# ── 2. Brute-force attack ─────────────────────────────────────────────────────

def _score_french(text: str) -> float:
    """
    Score how much *text* resembles French.

    Combines two signals:
      - Fraction of recognised French words in the tokenised text.
      - Inverse chi-squared distance to French letter frequencies.

    A higher score means the text is more likely to be valid French.
    """
    words = text.lower().split()
    if not words:
        return 0.0

    word_score = sum(1 for w in words if w in FRENCH_COMMON_WORDS) / len(words)

    letters = [c for c in text.upper() if c.isalpha()]
    if not letters:
        return word_score

    n = len(letters)
    counts = Counter(letters)
    chi2 = sum(
        (counts.get(c, 0) / n * 100 - FRENCH_LETTER_FREQUENCIES[c]) ** 2
        / FRENCH_LETTER_FREQUENCIES[c]
        for c in FRENCH_LETTER_FREQUENCIES
    )
    frequency_score = 1 / (1 + chi2)

    return 0.6 * word_score + 0.4 * frequency_score


def brute_force_caesar(
    ciphertext: str, top_n: int = 5
) -> list[tuple[int, float, str]]:
    """
    Try all 26 possible shifts and rank candidate plaintexts.

    Args:
        ciphertext: The encrypted text to attack.
        top_n:      Number of best candidates to return (default 5).

    Returns:
        A list of *(shift, score, plaintext)* tuples, best candidates first.
    """
    results = []
    for shift in range(26):
        plaintext = decrypt_caesar(ciphertext, shift)
        score = _score_french(plaintext)
        results.append((shift, score, plaintext))

    results.sort(key=lambda x: x[1], reverse=True)
    return results[:top_n]


def detect_key_caesar(ciphertext: str) -> tuple[int, str]:
    """
    Automatically identify the most probable Caesar shift.

    Returns:
        A *(shift, plaintext)* tuple for the best candidate.
    """
    best = brute_force_caesar(ciphertext, top_n=1)[0]
    return best[0], best[2]


# ── 3. Frequency-analysis key deduction (no brute force) ─────────────────────

def index_of_coincidence(text: str) -> float:
    """
    Compute the Index of Coincidence (IC) of *text*.

    IC = Σ f_i*(f_i-1) / N*(N-1)

    Reference values:
      French ≈ 0.074 | English ≈ 0.065 | Random ≈ 0.038
    """
    letters = [c for c in text.upper() if c.isalpha()]
    n = len(letters)
    if n <= 1:
        return 0.0
    counts = Counter(letters)
    return sum(f * (f - 1) for f in counts.values()) / (n * (n - 1))


def _chi2_with_shift(text: str, shift: int) -> float:
    """
    Compute chi-squared distance between the observed letter frequencies
    (after applying *shift*) and the expected French frequencies.

    A smaller value means the shift better explains the ciphertext.
    """
    letters = [c for c in text.upper() if c.isalpha()]
    n = len(letters)
    if n == 0:
        return float('inf')
    counts = Counter(letters)
    chi2 = 0.0
    for i, letter in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
        original_letter = chr((i - shift) % 26 + ord('A'))
        observed = counts.get(letter, 0) / n * 100
        expected = FRENCH_LETTER_FREQUENCIES[original_letter]
        chi2 += (observed - expected) ** 2 / expected
    return chi2


def deduce_key_by_frequency(ciphertext: str) -> tuple[int, float, float]:
    """
    Deduce the Caesar shift via chi-squared frequency analysis.

    Unlike brute-force, this method does not require scoring candidate
    plaintexts — it works directly on the ciphertext frequency distribution.

    Returns:
        A *(probable_shift, minimum_chi2, ic_value)* tuple.
    """
    ic = index_of_coincidence(ciphertext)

    best_shift = 0
    best_chi2 = float('inf')
    for shift in range(26):
        chi2 = _chi2_with_shift(ciphertext, shift)
        if chi2 < best_chi2:
            best_chi2 = chi2
            best_shift = shift

    return best_shift, best_chi2, ic


def full_analysis_caesar(ciphertext: str) -> dict:
    """
    Run a complete Caesar cipher analysis on *ciphertext*.

    Combines:
      - Index of Coincidence diagnostic
      - Chi-squared frequency deduction
      - Brute-force top candidates

    Returns:
        A dictionary with keys:
          ``ic``, ``ic_french``, ``diagnostic``,
          ``key_by_frequency``, ``min_chi2``, ``decrypted_freq``,
          ``top_brute_force_candidates``
    """
    ic = index_of_coincidence(ciphertext)
    best_shift, chi2, _ = deduce_key_by_frequency(ciphertext)
    top_candidates = brute_force_caesar(ciphertext, top_n=3)

    return {
        'ic': ic,
        'ic_french': IC_FRENCH,
        'diagnostic': (
            'monoalphabetic' if ic > 0.060
            else 'likely polyalphabetic'
        ),
        'key_by_frequency': best_shift,
        'min_chi2': chi2,
        'decrypted_freq': decrypt_caesar(ciphertext, best_shift),
        'top_brute_force_candidates': top_candidates,
    }


# ── Display ───────────────────────────────────────────────────────────────────

def print_analysis(ciphertext: str) -> None:
    """Print a formatted Caesar cipher analysis report to stdout."""
    res = full_analysis_caesar(ciphertext)
    print("=" * 60)
    print("  CAESAR ANALYSIS")
    print("=" * 60)
    print(
        f"  Ciphertext      : "
        f"{ciphertext[:60]}{'...' if len(ciphertext) > 60 else ''}"
    )
    print(f"  IC calculated   : {res['ic']:.4f}  (French ≈ {res['ic_french']})")
    print(f"  Diagnostic      : {res['diagnostic']}")
    print()
    print("  ── Frequency analysis (chi²) ──")
    print(f"  Probable key    : k = {res['key_by_frequency']}")
    print(f"  Minimum chi²    : {res['min_chi2']:.2f}")
    print(f"  Decrypted       : {res['decrypted_freq'][:80]}")
    print()
    print("  ── Brute-force (top 3) ──")
    for shift, score, text in res['top_brute_force_candidates']:
        print(f"  k={shift:2d}  score={score:.3f}  →  {text[:50]}")
    print("=" * 60)


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Example 1: basic encrypt / decrypt
    message = "Bonjour le monde, ceci est un message secret en francais"
    k = 13
    encrypted = encrypt_caesar(message, k)
    decrypted = decrypt_caesar(encrypted, k)
    print(f"Plaintext   : {message}")
    print(f"Shift       : k = {k}")
    print(f"Ciphertext  : {encrypted}")
    print(f"Decrypted   : {decrypted}\n")

    # Example 2: attack with hidden key
    ciphertext = encrypt_caesar(
        "les mathematiques sont le langage dans lequel dieu a ecrit l univers", 7
    )
    print(f"Ciphertext (k=7 hidden):")
    print(f"  {ciphertext}\n")
    print_analysis(ciphertext)
