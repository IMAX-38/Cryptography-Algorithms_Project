"""
classical/hill.py
-----------------
Hill Cipher — classical polygraphic substitution using linear algebra.

Provides:
  1. Encryption / decryption for 2x2 and 3x3 key matrices.
  2. Key-matrix validation (invertibility mod 26).
  3. Known-plaintext attack — recovering the key matrix from plaintext/ciphertext pairs.

Security note:
  Hill is linear, so a known-plaintext attack with only n plaintext/ciphertext
  pairs (n = matrix size) is sufficient to recover the full key matrix.
"""

from math import gcd

ALPHABET_SIZE = 26

# ── Mathematical helpers ───────────────────────────────────────────────────────

def _gcd(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return a

def _mod_inverse(a: int, m: int) -> int:
    def _ext_gcd(a, b):
        if b == 0:
            return a, 1, 0
        g, x, y = _ext_gcd(b, a % b)
        return g, y, x - (a // b) * y
    g, x, _ = _ext_gcd(a % m, m)
    if g != 1:
        raise ValueError(f"{a} is not invertible mod {m} (gcd={g})")
    return x % m

def _det(m: list[list[int]]) -> int:
    n = len(m)
    if n == 1:
        return m[0][0]
    if n == 2:
        return m[0][0] * m[1][1] - m[0][1] * m[1][0]
    if n == 3:
        return (m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
                m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
                m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]))
    raise ValueError("Only 2x2 and 3x3 matrices are supported.")

def _determinant_mod(matrix: list[list[int]], mod: int) -> int:
    return _det(matrix) % mod

def _transpose(m: list[list[int]]) -> list[list[int]]:
    return [[m[j][i] for j in range(len(m))] for i in range(len(m[0]))]

def _matmul(A: list[list[int]], B: list[list[int]]) -> list[list[int]]:
    rows_A, cols_A = len(A), len(A[0])
    rows_B, cols_B = len(B), len(B[0])
    if cols_A != rows_B:
        raise ValueError("Incompatible matrices for multiplication.")
    return [[sum(A[i][k] * B[k][j] for k in range(cols_A)) for j in range(cols_B)] for i in range(rows_A)]

def _matmul_vec(A: list[list[int]], v: list[int]) -> list[int]:
    rows_A, cols_A = len(A), len(A[0])
    return [sum(A[i][k] * v[k] for k in range(cols_A)) for i in range(rows_A)]

def _validate_matrix(K: list[list[int]]) -> tuple[bool, str]:
    n = len(K)
    if any(len(row) != n for row in K):
        return False, "Key matrix must be square."
    det = _determinant_mod(K, ALPHABET_SIZE)
    if det == 0:
        return False, "det(K) ≡ 0 (mod 26) — singular matrix."
    g = _gcd(det, ALPHABET_SIZE)
    if g != 1:
        return False, f"gcd(det(K) mod 26, 26) = gcd({det}, 26) = {g} ≠ 1 — matrix not invertible mod 26."
    return True, f"Valid — det(K) ≡ {det} (mod 26), invertible mod 26."

def _minor(K: list[list[int]], r: int, c: int) -> list[list[int]]:
    return [[K[i][j] for j in range(len(K[i])) if j != c] for i in range(len(K)) if i != r]

def _matrix_inverse_mod(K: list[list[int]], mod: int) -> list[list[int]]:
    det = _determinant_mod(K, mod)
    det_inv = _mod_inverse(det, mod)
    n = len(K)
    adj = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            min_mat = _minor(K, i, j)
            cofactor = _det(min_mat) * ((-1) ** (i + j))
            adj[j][i] = cofactor
    return [[(det_inv * adj[i][j]) % mod for j in range(n)] for i in range(n)]


# ── Text helpers ──────────────────────────────────────────────────────────────

def _text_to_vectors(text: str, block_size: int) -> list[list[int]]:
    text = ''.join(c for c in text.upper() if c.isalpha())
    while len(text) % block_size:
        text += 'X'
    return [
        [ord(c) - ord('A') for c in text[i:i + block_size]]
        for i in range(0, len(text), block_size)
    ]

def _vectors_to_text(vectors: list[list[int]]) -> str:
    return ''.join(chr(int(v) % ALPHABET_SIZE + ord('A')) for vec in vectors for v in vec)


# ── 1. Encryption / Decryption ────────────────────────────────────────────────

def validate_key(key_matrix: list[list[int]]) -> tuple[bool, str]:
    return _validate_matrix(key_matrix)

def encrypt_hill(text: str, key_matrix: list[list[int]]) -> str:
    K = key_matrix
    valid, msg = _validate_matrix(K)
    if not valid:
        raise ValueError(f"Invalid key matrix: {msg}")
    vectors = _text_to_vectors(text, len(K))
    return _vectors_to_text([[(v % ALPHABET_SIZE) for v in _matmul_vec(K, vec)] for vec in vectors])

def decrypt_hill(ciphertext: str, key_matrix: list[list[int]]) -> str:
    K = key_matrix
    valid, msg = _validate_matrix(K)
    if not valid:
        raise ValueError(f"Invalid key matrix: {msg}")
    K_inv = _matrix_inverse_mod(K, ALPHABET_SIZE)
    vectors = _text_to_vectors(ciphertext, len(K))
    return _vectors_to_text([[(v % ALPHABET_SIZE) for v in _matmul_vec(K_inv, vec)] for vec in vectors])


# ── 2. Known-plaintext attack ─────────────────────────────────────────────────

def known_plaintext_attack(
    pairs: list[tuple[str, str]], block_size: int
) -> dict:
    """
    Recover the Hill key matrix from known plaintext/ciphertext pairs.

    Principle: K = C × P⁻¹ mod 26, where P and C are matrices built from
    column vectors of the known pairs.
    """
    useful = pairs[:block_size]
    if len(useful) < block_size:
        raise ValueError(f"Need at least {block_size} pairs for Hill {block_size}x{block_size}.")

    P_cols, C_cols = [], []
    for pt, ct in useful:
        p = ''.join(c for c in pt.upper() if c.isalpha())[:block_size]
        c = ''.join(c for c in ct.upper() if c.isalpha())[:block_size]
        if len(p) < block_size or len(c) < block_size:
            raise ValueError(f"Each pair must have at least {block_size} letters.")
        P_cols.append([ord(ch) - ord('A') for ch in p])
        C_cols.append([ord(ch) - ord('A') for ch in c])

    P = _transpose(P_cols)
    C = _transpose(C_cols)

    det_P = _determinant_mod(P, ALPHABET_SIZE)
    if _gcd(det_P, ALPHABET_SIZE) != 1:
        return {
            'success': False,
            'error': f"Plaintext matrix P is not invertible mod 26 (det={det_P}). Choose different pairs.",
            'P': P, 'det_P': det_P,
        }

    P_inv = _matrix_inverse_mod(P, ALPHABET_SIZE)
    K_rec = [[(v % ALPHABET_SIZE) for v in row] for row in _matmul(C, P_inv)]

    # Verify: (K_rec @ P) % 26 == C
    verif = [[(v % ALPHABET_SIZE) for v in row] for row in _matmul(K_rec, P)]
    verified = (verif == C)

    return {
        'success': True,
        'recovered_key': K_rec,
        'P': P, 'C': C,
        'verified': verified,
        'message': "Key recovered successfully!" if verified else "Verification failed — inconsistent pairs.",
    }


def demo_known_plaintext_attack(real_key: list[list[int]]) -> None:
    """Demonstrate the known-plaintext attack and compare the recovered key."""
    import random, string
    n = len(real_key)
    result = {'success': False}
    attempts = 0
    pairs = []
    while not result['success'] and attempts < 50:
        attempts += 1
        pairs = [(pt := ''.join(random.choices(string.ascii_uppercase, k=n)),
                  encrypt_hill(pt, real_key)) for _ in range(n)]
        result = known_plaintext_attack(pairs, n)

    print(f"  Pairs used (after {attempts} attempt(s)):")
    for pt, ct in pairs:
        print(f"    plaintext='{pt}' → ciphertext='{ct}'")
    if result['success']:
        match = result['recovered_key'] == real_key
        print(f"\n  Real key      : {real_key}")
        print(f"  Recovered key : {result['recovered_key']}")
        print(f"  Match         : {match} ← {'✓' if match else '✗'}")
        print(f"  Verified C=KP : {result['verified']}")
    else:
        print(f"  ✗ Failed after {attempts} attempts — {result.get('error', '')}")


# ── Demo key matrices ─────────────────────────────────────────────────────────

DEMO_KEY_2X2: list[list[int]] = [[3, 3], [2, 5]]        # det=9, gcd(9,26)=1 ✓
DEMO_KEY_3X3: list[list[int]] = [
    [6, 24, 1], [13, 16, 10], [20, 17, 15],
]  # Classic Hill 3x3 example


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    for name, K in [("DEMO_KEY_2X2", DEMO_KEY_2X2), ("DEMO_KEY_3X3", DEMO_KEY_3X3)]:
        valid, msg = validate_key(K)
        print(f"  {name:<22} → {'✓' if valid else '✗'} {msg}")

    msg = "CRYPTOGRAPHY"
    enc = encrypt_hill(msg, DEMO_KEY_2X2)
    dec = decrypt_hill(enc, DEMO_KEY_2X2)
    print(f"\n  Plaintext  : {msg}\n  Ciphertext : {enc}\n  Decrypted  : {dec}")
    demo_known_plaintext_attack(DEMO_KEY_2X2)
