"""
classical/vigenere.py
---------------------
Vigenere Cipher — classical polyalphabetic substitution cipher.

Provides:
  1. Encryption / decryption using a keyword.
  2. Kasiski test — detecting repeated n-grams to estimate key length.
  3. Index-of-Coincidence analysis — confirming key length per subsequence.
  4. Full automatic cryptanalysis combining Kasiski + IC + chi-squared key recovery.

Security note:
  The Vigenere cipher is breakable with as little as a few hundred characters of
  ciphertext using the methods implemented here.  It must not be used for real data.
"""

from collections import Counter
from math import gcd
from functools import reduce

# ── French letter frequencies (%) ─────────────────────────────────────────────
FRENCH_LETTER_FREQUENCIES: dict[str, float] = {
    'A': 7.636, 'B': 0.901, 'C': 3.260, 'D': 3.669, 'E': 14.715,
    'F': 1.066, 'G': 1.054, 'H': 1.069, 'I': 7.529, 'J': 0.545,
    'K': 0.049, 'L': 5.456, 'M': 2.968, 'N': 7.095, 'O': 5.378,
    'P': 3.021, 'Q': 0.836, 'R': 6.553, 'S': 7.948, 'T': 7.244,
    'U': 6.311, 'V': 1.628, 'W': 0.114, 'X': 0.427, 'Y': 0.128,
    'Z': 0.326,
}
IC_FRENCH: float = 0.074


# ── Internal helpers ──────────────────────────────────────────────────────────

def _sanitize(text: str) -> str:
    """Strip non-alphabetic characters and convert to uppercase."""
    return ''.join(c.upper() for c in text if c.isalpha())


def _index_of_coincidence(text: str) -> float:
    """IC = Σ f_i*(f_i-1) / N*(N-1)"""
    n = len(text)
    if n <= 1:
        return 0.0
    counts = Counter(text)
    return sum(f * (f - 1) for f in counts.values()) / (n * (n - 1))


def _chi2_shift(subsequence: str, shift: int) -> float:
    """Chi-squared distance assuming a Caesar shift of `shift` on this subsequence."""
    n = len(subsequence)
    if n == 0:
        return float('inf')
    counts = Counter(subsequence)
    chi2 = 0.0
    for i, letter in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
        original = chr((i - shift) % 26 + ord('A'))
        observed = counts.get(letter, 0) / n * 100
        expected = FRENCH_LETTER_FREQUENCIES[original]
        chi2 += (observed - expected) ** 2 / expected
    return chi2


def _gcd_list(numbers: list[int]) -> int:
    """GCD of a list of integers."""
    if not numbers:
        return 1
    return reduce(gcd, numbers)


# ── 1. Encryption / Decryption ────────────────────────────────────────────────

def encrypt_vigenere(text: str, key: str) -> str:
    """
    Encrypt *text* with the Vigenere cipher using *key*.

    Non-alphabetic characters in *text* are preserved unchanged.
    E(m_i) = (m_i + k_{i mod |k|}) mod 26

    Args:
        text: Plaintext string (any case).
        key:  Keyword — only alphabetic characters are used.

    Returns:
        Uppercase ciphertext string.

    Raises:
        ValueError: If *key* contains no alphabetic characters.
    """
    key = _sanitize(key)
    if not key:
        raise ValueError("Key must contain at least one letter.")
    result = []
    idx = 0
    for c in text.upper():
        if c.isalpha():
            shift = ord(key[idx % len(key)]) - ord('A')
            result.append(chr((ord(c) - ord('A') + shift) % 26 + ord('A')))
            idx += 1
        else:
            result.append(c)
    return ''.join(result)


def decrypt_vigenere(text: str, key: str) -> str:
    """
    Decrypt a Vigenere-ciphered *text*.

    D(c_i) = (c_i - k_{i mod |k|}) mod 26

    Args:
        text: Ciphertext string.
        key:  The keyword used during encryption.

    Returns:
        Uppercase plaintext string.
    """
    key = _sanitize(key)
    if not key:
        raise ValueError("Key must contain at least one letter.")
    result = []
    idx = 0
    for c in text.upper():
        if c.isalpha():
            shift = ord(key[idx % len(key)]) - ord('A')
            result.append(chr((ord(c) - ord('A') - shift) % 26 + ord('A')))
            idx += 1
        else:
            result.append(c)
    return ''.join(result)


# ── 2. Kasiski test ───────────────────────────────────────────────────────────

def kasiski_test(
    ciphertext: str,
    ngram_length: int = 3,
    max_results: int = 10,
) -> dict:
    """
    Kasiski test — search for repeated n-grams in *ciphertext*.

    The spacing between repetitions is a probable multiple of the key length.

    Args:
        ciphertext:   The ciphertext to analyse.
        ngram_length: Length of n-grams to search for (3 = trigrams).
        max_results:  Maximum number of repeated n-grams to report.

    Returns:
        A dictionary with keys:
          ``ngrams``, ``distances``, ``gcd``, ``probable_lengths``
    """
    text = _sanitize(ciphertext)
    n = len(text)

    occurrences: dict[str, list[int]] = {}
    for i in range(n - ngram_length + 1):
        ng = text[i:i + ngram_length]
        occurrences.setdefault(ng, []).append(i)

    repeated = {ng: pos for ng, pos in occurrences.items() if len(pos) > 1}

    if not repeated:
        return {
            'ngrams': {},
            'distances': [],
            'gcd': None,
            'probable_lengths': [],
            'message': (
                f"No repeated {ngram_length}-grams found. "
                "Text too short or key too long?"
            ),
        }

    all_distances = []
    ngram_details = {}
    for ng, positions in sorted(repeated.items(), key=lambda x: len(x[1]), reverse=True)[:max_results]:
        dists = [positions[i + 1] - positions[i] for i in range(len(positions) - 1)]
        all_distances.extend(dists)
        ngram_details[ng] = {'positions': positions, 'distances': dists}

    factor_counter: dict[int, int] = Counter()
    for d in all_distances:
        for f in range(2, min(d + 1, 31)):
            if d % f == 0:
                factor_counter[f] += 1

    probable_lengths = sorted(factor_counter.items(), key=lambda x: x[1], reverse=True)[:8]
    common_gcd = _gcd_list(all_distances) if all_distances else None

    return {
        'ngrams': ngram_details,
        'distances': sorted(set(all_distances)),
        'gcd': common_gcd,
        'probable_lengths': probable_lengths,
    }


# ── 3. IC analysis — recover the key ─────────────────────────────────────────

def ic_by_key_length(
    ciphertext: str, max_key_length: int = 20
) -> list[tuple[int, float]]:
    """
    For each candidate key length k, split the ciphertext into k subsequences
    and compute the average IC.  The correct key length yields an IC close to
    IC_FRENCH (≈ 0.074).

    Returns:
        List of *(key_length, average_ic)* tuples sorted by proximity to IC_FRENCH.
    """
    text = _sanitize(ciphertext)
    results = []
    for k in range(1, max_key_length + 1):
        subsequences = [text[i::k] for i in range(k)]
        ics = [_index_of_coincidence(s) for s in subsequences if len(s) > 1]
        if ics:
            avg_ic = sum(ics) / len(ics)
            results.append((k, avg_ic))
    results.sort(key=lambda x: abs(x[1] - IC_FRENCH))
    return results


def recover_key(ciphertext: str, key_length: int) -> str:
    """
    Recover each letter of the key by chi-squared frequency analysis.

    For each position i in [0, key_length), extract the subsequence of
    ciphertext letters at positions congruent to i mod key_length, then
    find the shift minimising chi-squared against French frequencies.

    Args:
        ciphertext: Ciphertext string (letters only).
        key_length: The key length to use.

    Returns:
        The probable key as an uppercase string.
    """
    text = _sanitize(ciphertext)
    key = []
    for i in range(key_length):
        subsequence = text[i::key_length]
        best_shift = min(range(26), key=lambda d: _chi2_shift(subsequence, d))
        key.append(chr(best_shift + ord('A')))
    return ''.join(key)


def cryptanalyze_vigenere(
    ciphertext: str, max_key_length: int = 20
) -> dict:
    """
    Full automatic Vigenere cryptanalysis.

    Steps:
      1. Kasiski test  — estimate key length from repeated trigrams.
      2. IC analysis   — confirm key length via subsequence IC.
      3. Key recovery  — recover each key letter by chi-squared minimisation.

    Returns:
        A dictionary with keys:
          ``probable_length``, ``probable_key``, ``decrypted_text``,
          ``kasiski``, ``ic_by_length``
    """
    kasiski = kasiski_test(ciphertext)
    kasiski_top = kasiski['probable_lengths']

    ic_results = ic_by_key_length(ciphertext, max_key_length)
    length_by_ic = ic_results[0][0] if ic_results else 1

    probable_length = length_by_ic
    if kasiski_top:
        kasiski_top1 = kasiski_top[0][0]
        top3_ic = {r[0] for r in ic_results[:3]}
        if kasiski_top1 in top3_ic:
            probable_length = kasiski_top1

    probable_key = recover_key(ciphertext, probable_length)
    decrypted = decrypt_vigenere(ciphertext, probable_key)

    return {
        'probable_length': probable_length,
        'probable_key': probable_key,
        'decrypted_text': decrypted,
        'kasiski': kasiski,
        'ic_by_length': ic_results[:8],
    }


# ── Display ───────────────────────────────────────────────────────────────────

def print_cryptanalysis(ciphertext: str) -> None:
    """Print a formatted Vigenere cryptanalysis report to stdout."""
    res = cryptanalyze_vigenere(ciphertext)
    clean = _sanitize(ciphertext)
    print("=" * 65)
    print("  VIGENERE CRYPTANALYSIS")
    print("=" * 65)
    print(
        f"  Ciphertext ({len(clean)} letters) : "
        f"{ciphertext[:50]}{'...' if len(ciphertext) > 50 else ''}"
    )

    print("\n  ── Kasiski Test ──")
    if res['kasiski']['probable_lengths']:
        print("  Probable lengths (factor frequency):")
        for length, freq in res['kasiski']['probable_lengths'][:5]:
            print(f"    length {length:2d} → score {freq}")
        if res['kasiski']['ngrams']:
            print(f"  Repeated trigrams : {list(res['kasiski']['ngrams'].keys())[:5]}")
    else:
        print(f"  {res['kasiski'].get('message', 'No repetitions found.')}")

    print("\n  ── IC by Key Length (top 5) ──")
    for length, ic in res['ic_by_length'][:5]:
        bar = '█' * int(ic * 100)
        marker = '← ✓ close to French IC' if abs(ic - IC_FRENCH) < 0.005 else ''
        print(f"    k={length:2d}  IC={ic:.4f}  {bar}  {marker}")

    print("\n  ── Result ──")
    print(f"  Probable key length : {res['probable_length']}")
    print(f"  Probable key        : {res['probable_key']}")
    print(f"  Decrypted text      : {res['decrypted_text'][:100]}")
    print("=" * 65)


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    key = "CRYPTO"
    msg = (
        "les sciences mathematiques ont pour objet les relations "
        "entre les grandeurs et les mesures dans le monde physique"
    )
    enc = encrypt_vigenere(msg, key)
    print(f"Key        : {key}")
    print(f"Plaintext  : {msg[:60]}...")
    print(f"Ciphertext : {enc[:60]}...\n")

    enc_long = encrypt_vigenere(msg * 3, key)
    print_cryptanalysis(enc_long)
