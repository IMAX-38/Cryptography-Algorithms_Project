"""
symmetric/rc4.py
----------------
RC4 (Rivest Cipher 4) Stream Cipher — pure Python implementation.

RC4 generates a pseudo-random keystream via the KSA (Key Scheduling Algorithm)
and PRGA (Pseudo-Random Generation Algorithm), then XORs it with the plaintext.

Security note:
  RC4 is deprecated and must NOT be used in new systems.
  Known vulnerabilities include biases in the keystream that leak plaintext
  (as exploited against WEP and early TLS).  Use AES-GCM instead.
"""


def _rc4_keystream(key: bytes, length: int) -> bytes:
    """
    Generate `length` bytes of RC4 keystream from `key`.

    Steps:
      1. KSA  — initialise and permute S-box using the key.
      2. PRGA — generate pseudo-random bytes from the permuted S-box.
    """
    # KSA
    S = list(range(256))
    j = 0
    for i in range(256):
        j = (j + S[i] + key[i % len(key)]) % 256
        S[i], S[j] = S[j], S[i]

    # PRGA
    i = j = 0
    keystream = []
    for _ in range(length):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        keystream.append(S[(S[i] + S[j]) % 256])

    return bytes(keystream)


def encrypt_text(plaintext: str, key: str) -> bytes:
    """
    Encrypt a UTF-8 plaintext string with RC4.

    Args:
        plaintext: The message to encrypt.
        key:       The secret key string.

    Returns:
        Raw ciphertext bytes (XOR of plaintext and keystream).
    """
    key_bytes = key.encode('utf-8')
    data = plaintext.encode('utf-8')
    keystream = _rc4_keystream(key_bytes, len(data))
    return bytes(a ^ b for a, b in zip(data, keystream))


def decrypt_text(ciphertext: bytes, key: str) -> str:
    """
    Decrypt RC4 ciphertext back to a UTF-8 string.

    RC4 decryption is identical to encryption (XOR is symmetric).

    Args:
        ciphertext: The raw ciphertext bytes produced by encrypt_text().
        key:        The same secret key used for encryption.

    Returns:
        The decrypted plaintext string.
    """
    key_bytes = key.encode('utf-8')
    keystream = _rc4_keystream(key_bytes, len(ciphertext))
    return bytes(a ^ b for a, b in zip(ciphertext, keystream)).decode('utf-8', errors='replace')