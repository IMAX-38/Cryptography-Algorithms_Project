"""
symmetric/__init__.py
---------------------
Public API for the symmetric ciphers package.
"""

from .aes_cipher import (
    AESCipher,
    encrypt_text as aes_encrypt_text,
    decrypt_text as aes_decrypt_text,
    avalanche_cbc_demo,
    ctr_nonce_reuse_attack,
    benchmark_aes_key_sizes,
)

from .des_cipher import (
    des_generate_key,
    tdes_generate_key,
    des_encrypt_ecb,
    des_decrypt_ecb,
    des_encrypt_cbc,
    des_decrypt_cbc,
    tdes_encrypt_cbc,
    tdes_decrypt_cbc,
    encrypt_text as des_encrypt_text,
    decrypt_text as des_decrypt_text,
    benchmark_des_vs_3des,
)

from .rc4 import encrypt_text as rc4_encrypt_text, decrypt_text as rc4_decrypt_text

__all__ = [
    "AESCipher",
    "aes_encrypt_text", "aes_decrypt_text",
    "avalanche_cbc_demo", "ctr_nonce_reuse_attack", "benchmark_aes_key_sizes",
    "des_generate_key", "tdes_generate_key",
    "des_encrypt_ecb", "des_decrypt_ecb",
    "des_encrypt_cbc", "des_decrypt_cbc",
    "tdes_encrypt_cbc", "tdes_decrypt_cbc",
    "des_encrypt_text", "des_decrypt_text",
    "benchmark_des_vs_3des",
    "rc4_encrypt_text", "rc4_decrypt_text",
]
